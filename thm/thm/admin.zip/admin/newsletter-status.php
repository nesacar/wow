<h2>Newsletter</h2>
<hr />
<div class='group' style='width: 760px'>
<h3>Status: <?= @$lock ? "SLANJE JE U TOKU" : "SLANJE NIJE U TOKU" ?></h3>

<table width=80%>
  <tr bgcolor='#AAAAAA'><th>datum</th><th>poruka</th></tr>
  <?php
  $i=0;
  foreach($log as $l) {
    $trc = ++$i % 2 ? "#CCCCCC" : "#DDDDDD";
    echo "<tr bgcolor='$trc'><td width=120>".date("d.m.Y H:i:s",strtotime($l['datum']))."</td><td>{$l['poruka']}</td></tr>\n";
  }
  ?>
</table>


</div>

<?php if(@$lock) { ?>
  <form method="post" action="<?= AURI ?>nl_actions" onSubmit="return confirm('Are you sure that sending is being blocked?')">
    <input type='hidden' name='action' value='unlock-sending' />
    <input type='submit' value='Cancel blocked sending' />
  </form>
<?php } ?>


<plaintext>
<?php

//exit;
echo `ps -Af | grep send`;
echo "\n";
echo `uptime`;

$ut = $this->registry->db->selectRow("SHOW STATUS LIKE 'uptime'");
echo "MySQL uptime: ".round($ut['Value']/3600/24)." days\n\n";

echo "\n";
$linije =  file(__SITE_PATH."/chest/nldebug/snl.output.txt");
$l = 1;
foreach($linije as $ln) echo $l++." ".$ln;
exit;


?>