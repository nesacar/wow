<?php if(empty($pList)) return; ?>
<div>

<table class='tblh thvr' width=770 border="0" cellpadding="0" cellspacing="0">
<tr class='listtitle' ><th>PROIZVOD</th><th>BREND</th><th>DISTRIBUTER</th><th>KATEGORIJA</th><th>BROJ PRIKAZA</th></tr>
<?php
$i = 0; $sum = 0;
foreach($pList as $p) {
  $trc = ++$i % 2 ? "nepar":"par";
  if($p['cena']==0.00) $trc = "invisible";

  $brand = empty($brandNames[$p['brand']]) ? "-" : $brandNames[$p['brand']];
  $cat   = empty($cNames[$p['cat']]) ? "-" : $cNames[$p['cat']];
  $dist  = empty($distNames[$p['dist']]) ? "-" : $distNames[$p['dist']];

  $sum += $p['ct'];

  echo "<tr class='{$trc}'><td><a href='".AURI."gdk_product_edit/{$p['id']}'>{$p['title']}</a></td>"
      ."<td>{$brand}</td><td>{$dist}</td><td>{$cat}</td>\n"
      ."<td align='center'>{$p['ct']}</td></tr>\n";
}
?>
<tr class='listtitle'><th colspan='4' align='right'>Ukupno:</th><th><?= $sum ?></th></tr>
</table>
</div>
