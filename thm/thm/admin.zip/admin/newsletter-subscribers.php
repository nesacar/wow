<?php
$pageCnt = ceil($subcnt / $limit);

$page = isset($_GET['page']) ? $_GET['page'] : 1;
$page = min($pageCnt,max(0,$page));

?>

  <h2>Newsletter</h2>
  <hr />


 <div class='group' style='width: 460px; float: left;'>
  <h3>Primaoci poruka</h3>

Prikazano: <?= min($subcnt,$limit) ?> od <?= $subcnt ?> prijavljenih adresa. <br />
Strana:
<?php
for($pl=1; $pl<=$pageCnt; $pl++){
  if($pl > 1) echo "&nbsp; | &nbsp;";
  echo $pl == $page ? "<b>{$pl}</b>" : "<a href='".AURI."newsletter/subscribers?page={$pl}'>{$pl}</a>";
}
?>

<div style='height:600px;overflow:auto;margin-top:10px'>

<table width=450>
<tr bgcolor='#AAAAAA'><th width=36>br.</th><th>e-mail</th><th width=74>aktivan od</th><th width=24>X</th></tr>
<?php
$i=0; $acSum = 0; $bcSum = 0;
$badAddr = array();
  foreach($subscribers as $s) {
    $trc = ++$i % 2 ? "#CCCCCC" : "#DDDDDD";
    if(!preg_match("/^\w+[-_\w]*(\.[-_\w]+)*@\w+[-_\w]*(\.[-_\w]+)*\.[\w]{2,}$/",$s['email'])){
    	$trc = "#EEBBBB";
    	$badAddr[] = $s['id'];
    }

    $email = strlen($s['email'])>32 ? "<label title='{$s['email']}'>".substr($s['email'],0,29)."...</label>":$s['email'];

    echo "<tr bgcolor='$trc'><td>".($offset + $i)."</td><td>$email</td><td align=center>".date("d.m.Y", strtotime($s['started']))."</td>"
    		."<td align=center><a href='".AURI."newsletter/subscribers?deactivate={$s['id']}' onClick=\"return confirm('Deaktivacija adrese {$s['email']}?\\nPonovono aktiviranje nije moguće')\">x</a></td></tr>";
  }
?>
</table>
</div>

<?php

if(count($badAddr)){
	$bad = implode("#",$badAddr);
?>
  <form method=post action="<?= AURI ?>nl_actions">
  	<input type=hidden name='action' value='badusrdel'/>
  	<input type=hidden name='bad' value='<?= $bad ?>'/>
  	<input type=submit value='Obriši neispravne adrese'/>

  </form>
<?php
}
?>

</div>



<div class='group' style='width: 260px; float: right; clear: none; padding-left: 16px'>
	<h3>Nove adrese</h3>
	<form method='post' action="<?= AURI ?>nl_actions">
	  <input type=hidden name='action' value='usrpaste'/>
      <select name='status'>
      	<option value='1'>Aktivne adrese</option>
      	<option value='0'>Deaktivacija adresa</option>
      </select>
      <p>po jedna e-mail adresa u redu</p>
      <textarea name='usrnew' style='width:200px;height:500px;'></textarea>
      <br />
      <input type=submit value='Unesi'/>
	</form>
<?php
if(@$badnewaddr) echo "<br /><b>Neisprave adrese:</b><br />".$badnewaddr;
?>
</div>

<div style='clear:both;height:20px'></div>

<div class='group' style='width: 760px'>
  <h3>Deaktivirane adrese</h3>
  Ukupno <b><?= $inactivecnt ?></b> deaktiviranih adresa.

</div>
