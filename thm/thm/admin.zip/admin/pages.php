<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.8.18/jquery-ui.min.js" type="text/javascript"></script>
<link rel="stylesheet" href="<?= ATURI ?>css/humanity/jquery-ui-1.8.18.custom.css">
<script type="text/javascript">
$(document).ready(function() {
  $(".datum").datepicker({dateFormat:'yy-mm-dd',firstDay:1,changeMonth:true,changeYear:true,onSelect:setFilter,
    dayNamesMin:['N','P','U','S','Č','P','S'],
    monthNamesShort:['Jan','Feb','Mar','Apr','Maj','Jun','Jul','Avg','Sep','Okt','Nov','Dec']
    });
});
</script>

<h1>Lista članaka</h1>
<div class='group' style='width:757px;'>
  <form onSubmit="return false" id="af_form">
    <input type=text name='search' id='af_search' value='<?= @$_SESSION['af_search'] ?>' placeholder='Pretraga' style='width: 120px'/>
    <input type=button value='Pretraga' class="pretraga" onClick="setFilter()" />
      Kategorija:
    <select name='cat' id='af_cat' onChange="setFilter()" style='width: 90px'>
      <option value='0'>Sve kategorije</option>
      <?php
        foreach($catList as $c) {
          echo "<option value='{$c['id']}' ".($c['id']==@$_SESSION['af_cat'] ? "selected='selected'":"").">{$c['pos']}. ".(empty($c['title']) ? "bez naslova":$c['title'])."</option>\n";
          if(!empty($c['sub'])) foreach ($c['sub'] as $s)
            echo "<option value='{$s['id']}' ".($s['id']==@$_SESSION['af_cat'] ? "selected='selected'":"").">-- {$c['pos']}.{$s['pos']}. ".(empty($s['title']) ? "bez naslova":$s['title'])."</option>\n";
        }
      ?>
    </select>

    <?php if(!empty($authorList)) { ?>
    Autor:
    <select name='author' id='af_author' onChange="setFilter()" style='width: 110px'>
      <option value='0'>Svi autori</option>
      <?php
        foreach($authorList as $a) {
          echo "<option value='{$a['id']}' ".($a['id']==@$_SESSION['af_author'] ? "selected='selected'":"").">{$a['name']}</option>\n";
        }
      ?>
    </select>
    <?php } ?>

    od <input type=text name='d1' id='af_d1' value='<?= @$_SESSION['af_d1'] ?>' class='datum' style='width: 66px'/>
    do <input type=text name='d2' id='af_d2' value='<?= @$_SESSION['af_d2'] ?>' class='datum' style='width: 66px'/>
    <input type=button value='X' onClick="resetFilter()" />
    <span style='float:right'>
      <select name='listlimit' onChange="setFilter()" title="članaka po strani">
      	<option <?= @$_SESSION['af_listlimit']==50  ? "selected='selected'":"" ?>>50</option>
      	<option <?= @$_SESSION['af_listlimit']==100 ? "selected='selected'":"" ?>>100</option>
      	<option <?= @$_SESSION['af_listlimit']==200 ? "selected='selected'":"" ?>>200</option>
      	<option <?= @$_SESSION['af_listlimit']==500 ? "selected='selected'":"" ?>>500</option>
      </select>
    </span>
  </form>

</div>

<div id='article_filtered_list' style='clear:both'>
<?php include "pages-list.php"; ?>
</div>

<script type="text/javascript">
function setFilter(){
  $.post("<?= AURI ?>/page_list",$("#af_form").serialize(),function(data){$("#article_filtered_list").html(data)});
}
function resetFilter(){
  $("#af_search").val('');
  $("#af_type").val(0);
  $("#af_cat").val(0); $("#af_author").val(0);
  $("#af_d1").val('');$("#af_d2").val('');
  setFilter();
}
function setPage(p){
  if(p==0) p = $('#jump_to_page').val();
  $.post("<?= AURI ?>/page_list",{page_num:p},function(data){$("#article_filtered_list").html(data)});
}
</script>