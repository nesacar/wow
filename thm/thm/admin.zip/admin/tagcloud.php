<h2>Tag cloud</h2>

<div class='group' style='width:760px'>
  <form method="post" action="<?= AURI ?>tagcloud">
  <input type='hidden' name='tag_add' value='1' />
    <h3>Novi tag:</h3>
    Tag: <input type='text' name='tag' >
    veličina: <select name='tsize'>
      <?php for($i=1; $i<=5; $i++) echo "<option>{$i}</option>\n"; ?>
    </select>
    <input type='submit' value='Dodaj' />
  </form>
  <div class='spacer10'></div>
</div>

<div class='group' style='width:760px'>
  <h3>Tagovi:</h3>
  <table class='tblh'>
    <tr class='listtitle'><th>br.</th><th>tag</th><th>veličina</th><th width="24">x</th></tr>
    <?php
    $i = 0;
    foreach($tags as $t) {
      $trc = ++$i % 2 ? "nepar":"par";
      echo "<tr class='{$trc}'><td align='right'>{$i}</td><td><a target='_blank' href='".SURI."tagcloud/".htmlspecialchars($t['tag'],ENT_QUOTES)."'>".htmlspecialchars($t['tag'],ENT_QUOTES)."</a></td><td>{$t['size']}</td><td align='center'><a href='".AURI."/tagcloud_del/{$t['id']}' onclick=\"return confirm('Brisanje taga?');\" style='color:red'>x</a></td></tr>\n";
    }
    ?>
  </table>
</div>


