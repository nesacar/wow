<h1>Greška</h1>

<?= empty($e) ? "Nepoznata greška" : $e->getMessage() ?>

<br /><br />
<a href='javascript:history.back()'>&lt;&lt;NAZAD</a>

<br /><br />
<?php Common::dbg($e); ?>