<h2>Newsletter retargeting</h2>
<hr />

<form method='post' enctype='multipart/form-data' id="retarget_form">
  <div class='group' style='width: 760px'>
    <h3>Sadržaj poruke:</h3>
    <?php if(!empty($msg)) { ?>
      <input type='hidden' name='id_bnr' value='<?= @$b['id'] ?>' />
      <input type='hidden' name='img_up_mime' value='<?= @$msg['img_up']['mime'] ?>' />
      <input type='hidden' name='img_up_enc64' value='<?= @$msg['img_up']['enc64'] ?>' />
      <input type='hidden' name='img_down_mime' value='<?= @$msg['img_down']['mime'] ?>' />
      <input type='hidden' name='img_down_enc64' value='<?= @$msg['img_down']['enc64'] ?>' />
    <?php } ?>
    <table>
      <tr><td>Naslov: </td><td><input type='text' name='msg_subject' value="<?= @$msg['subject'] ?>" /></td></tr>
      <tr><td>Slika gore: </td><td><input type='file' name='img_up' /> link: http://<input type='text' name='url_up' value="<?= @$msg['img_up']['url'] ?>" /></td></tr>
      <tr><td colspan='2'><textarea name='msg_body' class='contentEditor' style='width:100%; height:400px'><?= @$msg['body'] ?></textarea></td></tr>
      <tr><td>Slika dole: </td><td><input type='file' name='img_down' /> link: http://<input type='text' name='url_down'  value="<?= @$msg['img_down']['url'] ?>"/></td></tr>
      <?php if(empty($b)) { ?>
        <tr><td valign='top'>Primaoci: </td><td><textarea name='users' style='width:100%; height:320px'><?= @$msg['users'] ?></textarea></td></tr>
      <?php } ?>
      <tr><td colspan='2'><input type='submit' name='preview' value='Pregledaj' /></td></tr>
    </table>
  </div>
  <?php if(!empty($msg)) { ?>
  <div class='group' style='width: 760px'>
    <h3>Pregled poruke:</h3>
    <h4><?= $msg['subject'] ?></h4>
    <div style="width: 600px; padding: 20px; background-color: #FFF; border: 1px solid #666">
    <?php
      if(!empty($msg['img_up'])) {
        if(!empty($msg['img_up']['url'])) echo "<a target='_blank' href=\"http://".str_replace("http://","",$msg['img_up']['url'])."\">";
        echo "<img src=\"data:{$msg['img_up']['mime']};base64,{$msg['img_up']['enc64']}\" style='width: 600px; height: auto' />";
        if(!empty($msg['img_up']['url'])) echo "</a>";
      }

      echo "<div style='padding: 5px 0; font-family: Arial; font-size:13px; text-align: justify'>{$msg['body']}</div>\n";

      if(!empty($msg['img_down'])) {
        if(!empty($msg['img_down']['url'])) echo "<a target='_blank' href=\"http://".str_replace("http://","",$msg['img_down']['url'])."\">";
        echo "<img src=\"data:{$msg['img_down']['mime']};base64,{$msg['img_down']['enc64']}\" style='width: 600px; height: auto' />";
        if(!empty($msg['img_down']['url'])) echo "</a>";
      }
    ?>
    </div>
    <input type='submit' name='send' value="Pošalji" id="retarget_send_button" />
  </div>
  <?php } ?>
</form>

<hr />

<?php if(!empty($b)) { ?>
<div class='group' style='width: 760px'>
  <h3>Banner:</h3>
  <div style='padding:5px'><img src='data:<?= $b['slikaMime'] ?>;base64,<?= $b['slikaEnc64'] ?>'/></div>
</div>
<?php } ?>
<?php if(!empty($users)) { ?>
<div class='group' style='width: 760px'>
  <h3>Primaoci: </h3>
  <table style='margin-top:10px'>
    <tr><td colspan='2'>Ukupno: <?= count(@$users) ?></td></tr>
  <?php
    $i=0;
  	foreach($users AS $u){
  		$trc = ++$i % 2 ? "#CCCCCC":"#DDDDDD";
    	echo "<tr bgcolor='$trc'><td>{$i}</td><td>{$u['email']}</td></tr>";
    }
  ?>
  </table>
</div>
<?php } ?>

<script type="text/javascript" src="<?= ATURI ?>js/tiny_mce/tiny_mce.js"></script >
<script type="text/javascript">
$(document).ready(function(){
  $('#retarget_form input').change(function(){$('#retarget_send_button').attr('disabled',true)})
  $('#retarget_form file').change(function(){$('#retarget_send_button').attr('disabled',true)})
  $('#retarget_form textarea').change(function(){$('#retarget_send_button').attr('disabled',true)})
});


tinyMCE.init({
  mode : "specific_textareas",
  editor_selector : "contentEditor",
  theme : "advanced",

  relative_urls : false,
  remove_script_host : false,

  plugins : "autolink,lists,advhr,advimage,advlink,inlinepopups,preview,searchreplace,contextmenu,paste,table,fullscreen,visualchars",

  // Theme options
  theme_advanced_buttons1 : "fullscreen,code,preview,cleanup,|,cut,copy,paste,pastetext,pasteword,|,undo,redo,|,search,replace,|,removeformat,visualchars,visualaid,|,help",
  theme_advanced_buttons2 : "formatselect,fontsizeselect,|,justifyleft,justifycenter,justifyright,justifyfull,|,bold,italic,underline,|,strikethrough,forecolor,backcolor,|,bullist,numlist,|,outdent,indent",
  theme_advanced_buttons3 : "link,unlink,anchor,|,sub,sup,charmap,|,hr,advhr,|,tablecontrols",
  theme_advanced_toolbar_location : "top",
  theme_advanced_toolbar_align : "left",
  theme_advanced_statusbar_location : "bottom",
//  theme_advanced_resizing : true,

  // Skin options
  skin : "o2k7",
  skin_variant: "silver",
  setup : function(ed) {ed.onChange.add(function() {$('#retarget_send_button').attr('disabled',true)})}

});
</script>