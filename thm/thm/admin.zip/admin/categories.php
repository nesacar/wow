<h1>UREĐIVANJE KATEGORIJA VESTI</h1>
<div class='infobox'>
<p>Na ovoj stranici možete uređivati kategorije TOP menija.</p>
<p>Ukoliko je status kategorije "0" neće se prikazivati u meniju.</p>
</div>

<div class='group'><b><a href='<?= AURI ?>category_new'>» Dodaj novu kategoriju</a></b></div>

<?php foreach($catList as $c){ ?>
  <div class='group'>
    <div class='top'>
      <?= $c['pos'] ?>.
      <a href='<?= AURI ?>category_edit/<?= $c['id'] ?>'><?= empty($c['title']) ? "bez naslova":$c['title'] ?></a>
      <div class='del'>
        <label title='Obriši'>
          <input type=button value='X' onClick="obrisi('<?= $c['id'] ?>')"/>
        </label>
      </div>
    </div>

    <?php if(!empty($c['sub'])) foreach($c['sub'] as $s) { ?>
      <div class='sub'>
        <div class='top'>
          <?= $s['pos'] ?>.
          <a href='<?= AURI ?>category_edit/<?= $s['id'] ?>'><?= empty($s['title']) ? "untitled":$s['title'] ?> <?= true || empty($s['title_eng']) ? "" : "<span style='font-size:11px'>({$s['title_eng']})</span>" ?></a>
          <div class='del'>
            <label title='Obriši'>
              <input type=button value='X' onClick="obrisi('<?= $s['id'] ?>')"/>
            </label>
          </div>
        </div>
      </div>
    <?php } ?>

    <div class='spacer0'></div>
  </div>
<?php } ?>


<script type="text/javascript">
function obrisi(id) {
  if(!confirm('Brisanje kategorije?\nUkoliko obrišete kategoriju svi članci iz kategorije će postati nevidljivi i neće se prikazivati na sajtu!\n\nNajbolje je da kategoriji ili podkategoriji stavite "0" (nula) u opciji "Pozicija u meniju" tada se neće prikazivati na sajtu.\n\nAdministrator mora da interveniše za povraćaj članaka u nove kategorije ili podkategorije.\nADMIN: Nikola Ivković, 063 230 191 ili nikola.ivkovic@weboperater.rs')) return false;
  $.post("<?= AURI ?>category_del", {id:id}, function(data){window.location.reload()});
}
</script>