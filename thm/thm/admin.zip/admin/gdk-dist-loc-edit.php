<?php if(empty($dist)) return; ?>

<script type="text/javascript" src="<?= ATURI ?>js/tiny_mce/tiny_mce.js"></script >
<script type="text/javascript" src="<?= ATURI ?>js/tinymce-init.js"></script >

<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?key=<?= $setup->gmap_api_key ?>&sensor=false"></script>
<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?libraries=places&sensor=false"></script>

<h1><?= $dist['title'] ?> lokacija: <?= empty($loc) ? "nova" : @$loc['title'] ?></h1>

<form method='post' enctype='multipart/form-data' action='<?= AURI ?>gdk_dist_loc_save'>
  <input type=hidden name='loc[id]' value='<?= @$loc['id'] ?>' />
  <input type=hidden name='loc[did]' value='<?= @$dist['id'] ?>' />

  <table width="100%">
    <tr><td>Poredak: </td><td><input type=text name='loc[pos]' value='<?= @$loc['pos'] ?>' style='width: 500px' /></td></tr>
    <tr><td>Naziv (opciono): </td><td><input type=text name='loc[title]' value='<?= @$loc['title'] ?>' style='width: 500px' /></td></tr>
    <tr><td>Adresa: </td><td><input type=text name='loc[addr]' value='<?= @$loc['addr'] ?>' style='width: 500px' /></td></tr>
    <tr><td>Grad (država): </td><td><input type=text name='loc[town]' value='<?= @$loc['town'] ?>' style='width: 500px' /></td></tr>
    <tr><td>Tel: </td><td><input type=text name='loc[tel]' value='<?= @$loc['tel'] ?>' style='width: 500px' /></td></tr>
    <tr><td>Radno vreme: </td><td><input type=text name='loc[bhours]' value='<?= @$loc['bhours'] ?>' style='width: 500px' /></td></tr>
  </table>

  <h2>Mapa:</h2>
  Pretraga: <input type='text' id='gm_search' style='width: 400px' placeholder="Unesite adresu ili naziv mesta" /> <span style='float:right'>[<a href='javascript:loc_ponisti()'>poništi lokaciju sa mape</a>]</span>
  <div class='spacer10'></div>
  <div id="gmap_canvas" style="width:100%; height:300px"></div>
  <input type="hidden" id="gmap_geoloc" name="loc[geoloc]" value="<?= @$loc['geoloc'] ?>" />
  <div class='spacer10'></div>
  <input type='submit' value='Potvrdi' />

</form>

<script type="text/javascript">
var defLoc = new google.maps.LatLng(44.802425118906775, 20.466316884994512);
var map,marker;
function initialize() {
  var mapOptions = {
    center: defLoc,
    zoom: 12,
    mapTypeId: google.maps.MapTypeId.ROADMAP
  };
  map = new google.maps.Map(document.getElementById("gmap_canvas"),
    mapOptions);

  setMarker(map);
  if($('#gmap_geoloc').val()!='') {
    var split  = $('#gmap_geoloc').val().split(',');
    var geoloc = new google.maps.LatLng(parseFloat(split[0]), parseFloat(split[1]));
    marker.setPosition(geoloc);
    marker.setVisible(true);
    map.setCenter(geoloc);
    map.setZoom(15);
  }

  google.maps.event.addListener(map, 'click', function(e) {
    marker.setOptions({position:e.latLng,visible:true});
    $('#gmap_geoloc').val(marker.getPosition().lat() + ',' + marker.getPosition().lng())
  });
  google.maps.event.addListener(marker, 'dragend', function(){ $('#gmap_geoloc').val(marker.getPosition().lat() + ',' + marker.getPosition().lng()) });

  var sinput = document.getElementById('gm_search');
  var sopt = {componentRestrictions: {country: 'rs'}};

  autocomplete = new google.maps.places.Autocomplete(sinput, sopt);
  google.maps.event.addListener(autocomplete, 'place_changed', function() {
    var place = autocomplete.getPlace();
    marker.setPosition(place.geometry.location);
    marker.setVisible(true);
    $('#gmap_geoloc').val(marker.getPosition().lat() + ',' + marker.getPosition().lng())
    map.setCenter(place.geometry.location);
    map.setZoom(15);
  })
}

function setMarker(mapa){
  var mOpt = {
        draggable:true,
        map:mapa,
        position: defLoc,
        visible:false
  }

  marker = new google.maps.Marker(mOpt);
}

function loc_ponisti(){
  marker.setVisible(false);
  $('#gmap_geoloc').val('');
  $('#gm_search').val('');
  map.setCenter(defLoc);
  map.setZoom(12);
}

$(document).ready(function(){initialize()});
</script>