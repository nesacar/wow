<script type="text/javascript" src="<?= ATURI ?>js/tiny_mce/tiny_mce.js"></script >
<script type="text/javascript" src="<?= ATURI ?>js/tinymce-init.js"></script >

<h1><?= empty($model) ? "Novi model" : "Izmena modela: ".$model['title'] ?></h1>
<div class='group' style='width:760px;'>
  <form method=post enctype='multipart/form-data' action="<?= AURI ?>car_model_save">
    <input type=hidden name='model[id]' value='<?= @$model['id'] ?>' />
    <table width="100%">
      <tr><td>Serija: </td><td>
        <select id='brand-selector' onChange="selectBrand(this.value)">
          <option value='-1'>Odaberite brend</option>
          <option value='0'>Serije bez brenda</option>
          <?php foreach($brandList as $b) echo "<option value='{$b['id']}' ".($b['id']==@$series['brand'] ? "selected='selected'":"").">{$b['title']}</option>\n"; ?>
        </select>

        <select name='model[series]' id='series-selector'>
          <option value='0'>Odaberite seriju</option>
          <?php if(!empty($seriesList)) foreach($seriesList as $s) echo "<option value='{$s['id']}' ".($s['id']==@$model['series'] ? "selected='selected'":"").">{$s['title']}</option>\n"; ?>
        </select>
      </td></tr>

      <tr><td>Kratak naziv: </td><td><input type=text name='model[short_title]' value='<?= @$model['short_title'] ?>' required='required' /></td></tr>
      <tr><td>Pun naziv: </td><td><input type=text name='model[title]' value='<?= @$model['title'] ?>' required='required' /></td></tr>
      <tr><td>Godina početka proizvodnje: </td><td><input type=text name='model[year]' value='<?= @$model['year'] ?>' /></td></tr>

      <tr><td>Vidljivost: </td><td><label title='model je vidljiv'><input type='checkbox' name='model[visible]' value='1' <?= @$model['visible'] ? "checked='checked'":"" ?> /> model je vidljiv</label></td></tr>

      <tr><td colspan=2><hr /><b>SEO:</b> </td></tr>
      <tr><td>Opis: </td><td><textarea name='model[descr]'><?= @$model['descr'] ?></textarea></td></tr>
      <tr><td>Ključne reči: </td><td><input type=text name='model[kwrds]'  value='<?= @$model['kwrds'] ?>'/></td></tr>
      <tr><td>Adresa (url): </td><td><input type=text name='model[furl]' value='<?= @$model['furl'] ?>'/></td></tr>
      <tr><td colspan=2><hr /></td></tr>

      <tr><td colspan=2><textarea name='model[html]' class='contentEditor' style='width:100%; height:200px'><?= @$model['html'] ?></textarea></td></tr>
      <tr><td colspan=2><hr /></td></tr>

      <tr><td>Fotografija: </td><td><input type=file name='img' /></td></tr>
      <tr><td colspan=2>
        <?php if(!empty($model)) { ?>
          <div style='width:220px; height: 126px; background-color: #F00; border: 1px solid #888'><div style='width:212px; height: 118px; border: 4px solid white;'>
          <?php if(!empty($model['img'])) echo "<img src=\"".SURI."image.php/".basename($model['img'])."?width=212&height=118&image=".SURI.$model['img']."\" />"; ?>
          </div></div>
        <?php } ?>
      </td></tr>


      <tr><td colspan=2><input type=submit value='Potvrdi'/></td></tr>
    </table>
  </form>
</div>

<script type="text/javascript">
function selectBrand(bid){
  $('#series-selector option:gt(0)').remove();
  $('#series-selector').val(0);
  if(bid==-1) return;

  $.post("<?= SURI ?>fillSelector",{selector:'series',parent:bid,includeDisabled:true},function(data){$('#series-selector').append(data)});
}
</script>