<script type="text/javascript" src="<?= ATURI ?>js/tiny_mce/tiny_mce.js"></script >
<script type="text/javascript" src="<?= ATURI ?>js/tinymce-init.js"></script >

<h1>Osnovna podešavanja:</h1>
<div class='group' style='width: 760px'>
  <form method='post' action="<?= AURI ?>settings_save">
    <p>Glavni naslov (main title) max 70 karaktera, 11 reči:</p>
    <input name='setup[main_title]' type=text value='<?= @$setup->main_title ?>' maxlength="70"  style='width:400px' />

    <p>&nbsp;</p>
    <p>Glavni opis (main description) max 170 karaktera, 70 reči: </p>
    <textarea rows='3' name='setup[main_descr]' style='width:400px'><?= @$setup->main_descr ?></textarea>

    <p>&nbsp;</p>
    <p>Glavne ključne reči od 5 do max 10, odvojene [, ]:</p>
    <input type=text name='setup[main_kwrds]' value='<?= @$setup->main_kwrds ?>'  style='width:400px' />
    <p class='primer'>Primer: tekst, tekst, test, tekst</p>

    <p>&nbsp;</p>
    <p>Footer:</p>
    <textarea rows='4' name='setup[main_footer]' class='contentEditor'><?= @$setup->main_footer ?></textarea>

    <p>&nbsp;</p>
    <p>Google analitika:</p>
    <textarea rows='4' name='setup[ga_code]'  style='width:400px'><?= @$setup->ga_code ?></textarea>

    <p>&nbsp;</p>
    <p>API key za Google mape:</p>
    <input name='setup[gmap_api_key]' type=text value='<?= @$setup->gmap_api_key ?>' maxlength="70"  style='width:400px' />

    <p>&nbsp;</p>
    <p>GNC (0 - 100):</p>
    <input name='setup[pgnc]' type=text value='<?= (int)@$setup->pgnc ?>' maxlength="70"  style='width:400px' />

    <p>&nbsp;</p>
    <p>Glavni e-mail:</p>
    <input name='setup[site_email]' type=text value='<?= @$setup->site_email ?>' maxlength="70"  style='width:400px' />

    <p>&nbsp;</p>
    <p>Facebook strana:</p>
    <input name='setup[link_fb]' type=text value='<?= @$setup->link_fb ?>' maxlength="70"  style='width:400px' />

    <p>&nbsp;</p>
    <p>Twitter strana:</p>
    <input name='setup[link_twt]' type=text value='<?= @$setup->link_twt ?>' maxlength="70"  style='width:400px' />

    <br />
    <input type=submit value='SNIMI'/>
  </form>
</div>