<div>
Pronađeno proizvoda: <?= $pCnt ?>
<div class='spacer10'></div>

<table class='tblh' width=770 border="0" cellpadding="0" cellspacing="0">
<tr class='listtitle' ><th>URL</th><th>PROIZVOD</th><th>BREND</th><th>DISTRIBUTER</th><th>KATEGORIJA</th><th>X</th></tr>
<?php
$i = 0;
foreach($pList as $p) {
  $trc = ++$i % 2 ? "nepar":"par";
  if($p['cena']==0.00) $trc = "invisible";
  if(GdkProduct::getImage($p)=="") $trc = "invalid";

  $cat   = empty($cNames[$p['cat']]) ? "-" : $cNames[$p['cat']];
  $dist  = empty($distNames[$p['dist']]) ? "-" : $distNames[$p['dist']];

  echo "<tr class='{$trc}'><td><a href='".AURI."gdk_product_edit/{$p['id']}'>{$p['furl']}</td></td><td><a href='".AURI."gdk_product_edit/{$p['id']}'>{$p['title']}</a></td>"
      ."<td>{$p['btitle']}</td><td>{$dist}</td><td>{$cat}</td>\n"
      ."<td align='center'><a href='".AURI."gdk_product_delete/{$p['id']}' onClick=\"return confirm('Brisanje proizvoda?')\" title='Brisanje proizvoda'>X</a></td></tr>\n";
}
?>
</table>
</div>

<?php
if($pgCt > 1){
  echo "<div class='group' style='width:755px;'>\n";
  if($pNum == 1) echo "« PREDHODNA | <b>1</b> | ";
  else {
    echo "<a href=\"javascript:setPage('".($pNum-1)."')\">« prethodna</a> | ";
    echo "<a href=\"javascript:setPage(1)\">1</a> | ";

    if($pNum > 2) echo " ... | <b>{$pNum}</b> | ";
    else echo " <b>2</b> | ";

  }
  if($pgCt > $pNum+1) echo "... | ";
  if($pNum == $pgCt) echo " sledeća »";
  else {
    echo "<a href=\"javascript:setPage('{$pgCt}')\">{$pgCt}</a> | ";
    echo "<a href=\"javascript:setPage('".($pNum+1)."')\">SLEDEĆA »</a>";
  }
?>
<div style='float:right'>STRANA:
<input type=text id='jump_to_page' style='width:16px;text-align:right' onkeydown="if(event.which==13) setPage(0)" />
<a href="javascript:setPage(0)">IDI »</a>
</div>
</td></tr>
<?
} // end if($page_count>1);
?>
