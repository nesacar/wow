<script type="text/javascript" src="<?= ATURI ?>js/tiny_mce/tiny_mce.js"></script >
<script type="text/javascript" src="<?= ATURI ?>js/tinymce-init.js"></script >

<h1>Arhi Club podešavanja:</h1>
<div class='group' style='width: 760px'>
  <form method='post' action="<?= AURI ?>arhiclub_settings_save">
    <p>Naslov (title) max 70 karaktera, 11 reči:</p>
    <input name='setup[arhiclub_title]' type=text value='<?= @$setup->arhiclub_title ?>' maxlength="70"  style='width:400px' />

    <p>&nbsp;</p>
    <p>Opis (description) max 170 karaktera, 70 reči: </p>
    <textarea rows='3' name='setup[arhiclub_descr]' style='width:400px'><?= @$setup->arhiclub_descr ?></textarea>

    <p>&nbsp;</p>
    <p>Ključne reči od 5 do max 10, odvojene [, ]:</p>
    <input type=text name='setup[arhiclub_kwrds]' value='<?= @$setup->arhiclub_kwrds ?>'  style='width:400px' />
    <p class='primer'>Primer: tekst, tekst, test, tekst</p>

    <p>&nbsp;</p>
    <p>Login box:</p>
    <textarea rows='4' name='setup[arhiclub_loginbox]' style='width: 500px; height: 80px'><?= @$setup->arhiclub_loginbox ?></textarea>

    <p>&nbsp;</p>
    <p>HTML 1:</p>
    <textarea rows='4' name='setup[arhiclub_html1]' class='contentEditor'><?= @$setup->arhiclub_html1 ?></textarea>

    <p>&nbsp;</p>
    <p>HTML 2:</p>
    <textarea rows='4' name='setup[arhiclub_html2]' class='contentEditor'><?= @$setup->arhiclub_html2 ?></textarea>

    <p>&nbsp;</p>
    <p>Footer:</p>
    <textarea rows='4' name='setup[arhiclub_footer]' class='contentEditor'><?= @$setup->arhiclub_footer ?></textarea>


    <br />
    <input type=submit value='SNIMI'/>
  </form>
</div>