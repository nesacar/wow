<script type="text/javascript">
function resetujNovosti(){
  var brs = parseInt($('#news_num').val());
  if(isNaN(brs)) { $('#nnum').val(0); return; }
  $('#nnum').val(brs);

  var stavka = $('#nl_nmustra').html();
  var target = $('#nl_stavke').html('');

  for(var i=2; i<=brs; i++) target.append(stavka.replace(/%_br_%/g,i));
}
function resetujBanere(){
	var brb = parseInt($('#banner_num').val());
  if(isNaN(brb)) { $('#bnum').val(0); return; }
  $('#bnum').val(brb);

 	var baner  = $('#nl_bmustra').html();
 	var target = $('#nl_baneri').html('');

  for(var i=1; i<=brb; i++) target.append(baner.replace(/%_br_%/g,i).replace(/%_brx3_%/g,Math.max((i-2)*3+1,0)));

}

function checkNLForm(f){
  var brs = parseInt($('#nnum').val());
  var brb = parseInt($('#bnum').val());
  if(isNaN(brs) || isNaN(brb) || brs <= '0'){alert('Neispravan broj novosti/banner-a'); return false;}

  // provera novosti:
  for(var i=1; i<=brs; i++) if(f.elements['id_article_'+i].value==''){alert('Nije odabrana novost '+i); return false;}
  // provera banner-a
  if(f.elements['banner300'].value=='') {alert('Nije odabran banner uz novost 1'); return false;}
  for(var i=1; i<=brb; i++)if(f.elements['id_nlb_'+i].value==''){alert('Nije odabran banner '+i); return false;}

}

var abstractArr = new Array();
<?php foreach($articles as $a) echo "abstractArr[{$a['id']}] = '".SURI."{$a['timg']}';\n"; ?>

function setAbstractImg(){
  var imgurl = abstractArr[$("#id_article_1").val()];
  var cpos   = $("#img_abstract_cp").val();
  var img = "<?= SURI ?>image.php?width=418&height=250&cropratio=418:250&cropposition="+cpos+"&image="+imgurl;
  $("#img_abstract_1").attr('src',img).css({display:'block'});
}
</script>

<h2>Newsletter</h2>
<hr />
<div class="group" style='width: 760px'>
  <h3>
  	Broj novosti: <input type=text id='news_num' style='width: 72px; text-align:right' onkeydown="if(event.which==13)resetujNovosti()" /><input type=button value='Primeni' onClick='resetujNovosti()'/> &nbsp;&nbsp;&nbsp;
  	Broj horizontalnih banner-a: <input type=text id='banner_num' style='width: 72px; text-align:right' onkeydown="if(event.which==13)resetujBanere()" /><input type=button value='Primeni' onClick='resetujBanere()'/>
  </h3>
</div>

<form method=post action="<?= AURI ?>nl_actions" enctype="multipart/form-data" onSubmit="return checkNLForm(this)">
  <input type=hidden name='action' value='prepare' />
  <input type=hidden name='nnum' id='nnum' value='0'/>
  <input type=hidden name='bnum' id='bnum' value='0'/>

  <div class='group' style='width: 760px'>
    Naslov: <input type=text name='subject' />
  </div>

  <div class='group' style='width: 760px'>
    Novost 1:
    <select name='id_article_1' id='id_article_1' onChange="setAbstractImg()">
      <option value=''>Odaberite članak</option>
      <?php
        foreach($articles as $a) echo "<option value='{$a['id']}'>{$a['title']}</option>\n";
      ?>
    </select>
    <select name='cropposition' id='img_abstract_cp' onChange="setAbstractImg()">
      <option value='left'>Levo</option>
      <option value='left_half'>25% levo</option>
      <option value='center'>Sredina  </option>
      <option value='right_half'>25% Desno</option>
      <option value='right'>Desno</option>
    </select>
    <br /><br />
    <img id='img_abstract_1' style='display:none' />
  </div>

  <div class='group' style='width: 760px'>
    Banner uz novost 1:
    <select name='banner300'>
      <option value=''>Odaberite banner</option>
      <?php
        /*foreach($banners2 as $b) echo "<option value='{$b['id']}'>{$b['url']}</option>\n";*/
      foreach($banners2 as $b){ ?>
        <option value="<?php echo $b['id']; ?>"><?php if(!empty($b['name'])){ echo $b['name']; }else{ echo $b['url']; } ?></option>
      <?php } ?>
    </select>
  </div>
  <div class='group' style='width: 760px'>
    <div id='nl_stavke'></div>
  </div>
  <div class='group' style='width: 760px'>
    <div id='nl_baneri'></div>
  </div>



  <input type=submit value='Potvrdi'/>
</form>



<div id='nl_nmustra' style='display:none'>
  Novost %_br_%:
  <select name='id_article_%_br_%'>
  	<option value=''>Odaberite članak</option>
    <?php
    	foreach($articles as $a) echo "<option value='{$a['id']}'>{$a['title']}</option>\n";
    ?>
  </select>
  <br />

</div>
<div id='nl_bmustra' style='display:none'>
	Horizontalni banner %_br_%:
	<select name='id_nlb_%_br_%'>
		<option value=''>Odaberite banner</option>
		<?php
			/*foreach($banners as $b) echo "<option value='{$b['id']}'>{$b['url']}</option>\n";*/
        foreach($banners as $b){ ?>
          <option value="<?php echo $b['id']; ?>"><?php if(!empty($b['name'])){ echo $b['name']; }else{ echo $b['url']; } ?></option>
        <?php } ?>
	</select>
  nakon novosti <input type=text name='after_%_br_%' value='%_brx3_%' size=5/>
	<br />
</div>
