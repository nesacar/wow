<h1><?= empty($engine) ? "Novi motor" : "Izmena motora: ".$engine['title'] ?></h1>
<div class='group' style='width:760px;'>
  <form method=post action="<?= AURI ?>car_engine_save">
    <input type=hidden name='engine[id]' value='<?= @$engine['id'] ?>' />
    <table width="100%" class='tblh'>
      <tr><td>Model: </td><td>
        <select id='brand-selector' onChange="selectBrand(this.value)">
          <option value='-1'>Odaberite brend</option>
          <option value='0'>Serije bez brenda</option>
          <?php foreach($brandList as $b) echo "<option value='{$b['id']}' ".($b['id']==@$series['brand'] ? "selected='selected'":"").">{$b['title']}</option>\n"; ?>
        </select>

        <select id='series-selector' onChange="selectSeries(this.value)">
          <option value='-1'>Odaberite seriju</option>
          <option value='0'>Modeli bez serije</option>
          <?php if(!empty($seriesList)) foreach($seriesList as $s) echo "<option value='{$s['id']}' ".($s['id']==@$model['series'] ? "selected='selected'":"").">{$s['title']}</option>\n"; ?>
        </select>

        <select name='engine[model]' id='model-selector'>
          <option value='0'>Odaberite model</option>
          <?php if(!empty($modelList)) foreach($modelList as $m) echo "<option value='{$m['id']}' ".($m['id']==@$engine['model'] ? "selected='selected'":"").">{$m['title']}</option>\n"; ?>
        </select>

      </td></tr>

      <tr><td>Kratak naziv: </td><td><input type=text name='engine[short_title]' value='<?= @$engine['short_title'] ?>' required='required' /></td></tr>
      <tr><td>Pun naziv: </td><td><input type=text name='engine[title]' value='<?= @$engine['title'] ?>' required='required' /></td></tr>
      <tr><td>Vidljivost: </td><td><label title='engine je vidljiv'><input type='checkbox' name='engine[visible]' value='1' <?= @$engine['visible'] ? "checked='checked'":"" ?> /> model je vidljiv</label></td></tr>

      <tr><td colspan=2><hr /><b>SEO:</b> </td></tr>
      <tr><td>Opis: </td><td><textarea name='engine[descr]'><?= @$engine['descr'] ?></textarea></td></tr>
      <tr><td>Ključne reči: </td><td><input type=text name='engine[kwrds]'  value='<?= @$engine['kwrds'] ?>'/></td></tr>
      <tr><td>Adresa (url): </td><td><input type=text name='engine[furl]' value='<?= @$engine['furl'] ?>'/></td></tr>

      <tr><td colspan=2><hr /><b>KARAKTERISTIKE:</b> </td></tr>
      <tr><td colspan=2>
        <table style='width: 400px; float:left'>
          <tr class='par'><td>Gorivo: </td><td><select name='engine[fuel]' id='fuel-selector'>
              <option value='petrol'>Benzin</option>
              <option value='diesel'>Dizel</option>
              <option value='cng'>TNG</option>
              <option value='electric'>Električni</option>
              <option value='hybrid'>Hibrid</option>
            </select>
          </td></tr>
          <?php if(!empty($engine['fuel'])) { ?><script type="text/javascript">$('#fuel-selector').val('<?= $engine['fuel'] ?>')</script><?php } ?>

          <?php
            $params = array(
                'cylinders'     => 'Broj cilindara',
                'displacement'  => 'Zapremina [ccm]',
                'power'         => 'Snaga [kW(KS)]',
                'torque'        => 'Obrtni moment [Nm]',
                'fuel_system'   => 'Sistem ubrizgavanja',
                'co2'           => 'Emisija CO2 [g/km]',
                'top_speed'     => 'Maksimalna brzina [km/h]',
                'acceleration'  => 'Ubrzanje do 100km/h [s]',
                'fc_city'       => 'Potrošnja u gradu [l/100km]',
                'fc_highway'    => 'Potrošnja na otvorenom [l/100km]',
                'fc_combined'   => 'Kombinovana potrošnja [l/100km]',
                'drive_type'    => 'Pogon',
                'gearbox'       => 'Menjač',
                'brakes_front'  => 'Prednje kočnice',
                'brakes_rear'   => 'Zadnje kočnice',
                'tires'         => 'Veličina pneumatika',
                'length'        => 'Dužina [mm]',
                'width'         => 'Širina [mm]',
                'height'        => 'Visina [mm]',
                'track_front'   => 'Prednje rastojanje među točkovima [mm]',
                'track_rear'    => 'Zadnje rastojanje među točkovima [mm]',
                'wheelbase'     => 'Međuosovinsko rastojanje [mm]',
                'gnd_clearance' => 'Klirens [mm]',
                'cargo_volume'  => 'Prtljažnik [l]',
                'drag'          => 'Aerodinamičnost',
                'weight'        => 'Masa praznog vozila [kg]',
                'weight_limit'  => 'Maksimalna masa [kg]'
            );

            $i=0;
            foreach($params as $name => $title) echo "<tr class='".(++$i % 2 ? "nepar":"par")."'><td>{$title}: </td><td><input type='text' name='engine[{$name}]' value='".@$engine[$name]."' /></td></tr>\n";
          ?>
        </table>
        <div style='float:right;width: 320px'>
          <b>DIRECT PASTE:</b>
          <p>jedan red - jedan parametar, počevši od "Broj cilindara"</p>
          <div style='float:left; width: 150px; margin-top: 5px; text-align: center'>mesto za parametre:</div>
          <div style='float:left; width: 140px; margin-top: 5px; margin-left: 10px; text-align: center'>primer:</div>
          <textarea style='width: 150px; height: 500px; margin-top: 5px' name='engine[directpaste]' ></textarea>
          <textarea style='width: 140px; height: 500px; margin-top: 5px; margin-left: 10px' disabled>5
2497
187(251)
361
Direct Injection
185
249
6.5
-
-
7.8
Front Wheel Drive
6 speed automatic
Ventilated Discs
solid discs
-
4369
1783
1420
1,547
1560
2647
132
334
0,31
-
-
          </textarea>
        </div>


      </td></tr>


      <tr><td colspan=2><input type=submit value='Potvrdi'/></td></tr>
    </table>
  </form>
</div>

<script type="text/javascript">
function selectBrand(bid){
  $('#model-selector option:gt(0)').remove();
  $('#model-selector').val(0);
  $('#series-selector option:gt(1)').remove()
  $('#series-selector').val(-1);
  if(bid==-1) return;

  $.post("<?= SURI ?>fillSelector",{selector:'series',parent:bid,includeDisabled:true},function(data){$('#series-selector').append(data)});
}
function selectSeries(sid){
  $('#model-selector option:gt(0)').remove();
  $('#model-selector').val(0);
  if(sid==-1) return;

  $.post("<?= SURI ?>fillSelector",{selector:'model',parent:sid,includeDisabled:true},function(data){$('#model-selector').append(data)});
}
</script>

<div id='direct-paste-placeholder-html' style='display:none'>
5
2497
187(251)
361
Direct Injection
185
249
6.5
-
-
7.8
Front Wheel Drive
6 speed automatic
Ventilated Discs
solid discs
-
4369
1783
1420
1,547
1560
2647
132
334
0,31
-
-
</div>