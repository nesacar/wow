<!DOCTYPE HTML>
<html>
<head>
<meta charset="UTF-8" />
<title><?= $setup->main_title ?> - Admin</title>
<link href="<?= ATURI ?>css/login.css" rel="stylesheet" type="text/css" />
<link rel="icon" href="<?= SURI ?>favicon.ico"/>
 <meta name="author" content="WebOperater [http://weboperater.com]" />
<!-- input blank on click -->
<script type="text/javascript">
function blank(a) { if(a.value == a.defaultValue) a.value = ""; }
function unblank(a) { if(a.value == "") a.value = a.defaultValue; }
</script>
</head>
<body>
<div id="containerlogin">
<div id="logbox">
<div id="logo">
<img src="<?= SURI ?>/thm/admin/images/logo.png" width="220" height="66" alt="<?= $setup->main_title ?>">
</div>
<div id="login_form">
<form name="Login" method="post" />
<input type="hidden" name="action" value="login" />
<input type="text"  name="li_usr" value="korisničko ime" maxlength="500" size="50" onFocus="blank(this)" onBlur="unblank(this)" />
<input type="password"  name="li_pwd"  value="**********" maxlength="500" size="50"  onFocus="blank(this)" onBlur="unblank(this)"/>
<input type="submit" name="submit"  value="LOGIN"  />
</form>
</div><!-- login_form kraj -->
</div><!-- logbox kraj -->

<div id="footerlogin">&copy; <?php echo date("Y"); ?> - <a href="<?= SURI ?>"> LuxLife.rs</a> - <em>CMS by <a href="#" target="_blank">Mini STUDIO Publishing Group</em></a></div>
</div><!-- containerlogin kraj -->
</body>
</html>