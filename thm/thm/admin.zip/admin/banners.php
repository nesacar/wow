<h1>Baneri</h1>
  <form method='post' action="<?= AURI ?>banners_save">

    <div class='group' style='width: 760px'>
      <h2>Horizontalni baneri:</h2>
      <p><label title="Poziija H1 (zaglavlje)"><input type='checkbox' name='setup[bnr_H1]' value='1' <?= @$setup->bnr_H1 ? "checked='checked'":"" ?> /> Pozicija H1 (zaglavlje)</label> <span class='tip'>ne važi ako je uključen BH2</span></p>
      <p><label title="Poziija H2 125px (ispod menija)"><input type='checkbox' name='setup[bnr_H2_125]' value='1' <?= @$setup->bnr_H2_125 ? "checked='checked'":"" ?> /> Pozicija H2 125px (ispod menija)</label></p>
      <p><label title="Poziija H2 250px (ispod menija)"><input type='checkbox' name='setup[bnr_H2_250]' value='1' <?= @$setup->bnr_H2_250 ? "checked='checked'":"" ?> /> Pozicija H2 250px (ispod menija)</label></p>
      <p><label title="Poziija H3 (sredina)"><input type='checkbox' name='setup[bnr_H3]' value='1' <?= @$setup->bnr_H3 ? "checked='checked'":"" ?> /> Pozicija H3 (sredina)</label></p>
      <p><label title="Poziija C1 (unutar stranice)"><input type='checkbox' name='setup[bnr_C1]' value='1' <?= @$setup->bnr_C1 ? "checked='checked'":"" ?> /> Pozicija C1 (ispod ključnih reči)</label></p>
    </div>

    <div class='group' style='width: 760px'>
      <h2>Baneri desno:</h2>
      <p><label title="Poziija D1 - 300x250 (gore)"><input type='checkbox' name='setup[bnr_D1_300x250]' value='1' <?= @$setup->bnr_D1_300x250 ? "checked='checked'":"" ?> /> Pozicija D1 - 300x250 (gore)</label></p>
      <p><label title="Poziija D1 - 300x600 (gore)"><input type='checkbox' name='setup[bnr_D1]' value='1' <?= @$setup->bnr_D1 ? "checked='checked'":"" ?> /> Pozicija D1 - 300x600 (gore)</label></p>
      <p><label title="Poziija D2 (sredina)"><input type='checkbox' name='setup[bnr_D2]' value='1' <?= @$setup->bnr_D2 ? "checked='checked'":"" ?> /> Pozicija D2 (sredina)</label></p>
      <p><label title="Poziija D3 (dole)"><input type='checkbox' name='setup[bnr_D3]' value='1' <?= @$setup->bnr_D3 ? "checked='checked'":"" ?> /> Pozicija D3 (dole)</label></p>
    </div>

    <div class='group' style='width: 760px'>
      <h2>Baneri za GDK:</h2>
      <p><label title="Poziija GDK H1 (630 gore)"><input type='checkbox' name='setup[bnr_GDK_H1]' value='1' <?= @$setup->bnr_GDK_H1 ? "checked='checked'":"" ?> /> Pozicija GDK H1 (630 gore)</label></p>
      <p><label title="Poziija GDK H2 (487 gore)"><input type='checkbox' name='setup[bnr_GDK_H2]' value='1' <?= @$setup->bnr_GDK_H2 ? "checked='checked'":"" ?> /> Pozicija GDK H2 (487 gore)</label></p>
      <p>
        <label title="Poziija GDK H3 (487 dole)"><input type='checkbox' name='setup[bnr_GDK_H3]' value='1' <?= @$setup->bnr_GDK_H3 ? "checked='checked'":"" ?> /> Pozicija GDK H3 (487 dole)</label> &nbsp;
        <label title="Red nakon koga se prikazuje GDK H3">prikaži nakon reda: <input type='text' name='setup[bnr_GDK_H3_pos]' value='<?= (int)@$setup->bnr_GDK_H3_pos ?>' /></label>
      </p>
      <p><label title="Poziija GDK H4 (630 dole)"><input type='checkbox' name='setup[bnr_GDK_H4]' value='1' <?= @$setup->bnr_GDK_H4 ? "checked='checked'":"" ?> /> Pozicija GDK H4 (630 dole)</label></p>
    </div>

    <div class='group' style='width: 760px'>
      <h2>Baneri za ADRESAR:</h2>
      <p><label title="Poziija ADR H1 (gore)"><input type='checkbox' name='setup[bnr_ADR_H1]' value='1' <?= @$setup->bnr_ADR_H1 ? "checked='checked'":"" ?> /> Pozicija ADR H1 (gore)</label></p>
      <p>
        <label title="Poziija ADR H2 (sredina)"><input type='checkbox' name='setup[bnr_ADR_H2]' value='1' <?= @$setup->bnr_ADR_H2 ? "checked='checked'":"" ?> /> Pozicija ADR H2 (sredina)</label> &nbsp;
        <label title="Red nakon koga se prikazuje ADR H2">prikaži nakon reda: <input type='text' name='setup[bnr_ADR_H2_pos]' value='<?= (int)@$setup->bnr_ADR_H2_pos ?>' /></label>
      </p>
      <p><label title="Poziija ADR H3 (dole)"><input type='checkbox' name='setup[bnr_ADR_H3]' value='1' <?= @$setup->bnr_ADR_H3 ? "checked='checked'":"" ?> /> Pozicija ADR H3 (dole)</label></p>
    </div>

    <div class='group' style='width: 760px'>
      <h2>Brendiranje:</h2>
      <p><label title="Poziija BL (brendiranje levo)"><input type='checkbox' name='setup[bnr_BL]' value='1' <?= @$setup->bnr_BL ? "checked='checked'":"" ?> /> Pozicija BL (brendiranje levo) </label></p>
      <p><label title="Poziija BR (brendiranje desno)"><input type='checkbox' name='setup[bnr_BR]' value='1' <?= @$setup->bnr_BR ? "checked='checked'":"" ?> /> Pozicija BR (brendiranje desno) </label></p>
      <p><label title="fiksirane pozadine"><input type='checkbox' name='setup[bnr_fix]' value='1' <?= @$setup->bnr_fix ? "checked='checked'":"" ?> /> fiksirane pozadine</label> <!-- span class='tip'>ne važi ako je uključen BH1 ili BH2</span --></p>
      <hr />
      <p><label title="Poziija BH1 (brendiranje gore)"><input type='checkbox' name='setup[bnr_BH1]' value='1' <?= @$setup->bnr_BH1 ? "checked='checked'":"" ?> /> Pozicija BH1 (brendiranje gore) </label></p>
      <p><label title="Poziija BH2 (brendiranje logotipa)"><input type='checkbox' name='setup[bnr_BH2]' value='1' <?= @$setup->bnr_BH2 ? "checked='checked'":"" ?> /> Pozicija BH2 (brendiranje logotipa) </label></p>
      <p><label title="Poziija BH3 (brendiranje slajdera)"><input type='checkbox' name='setup[bnr_BH3]' value='1' <?= @$setup->bnr_BH3 ? "checked='checked'":"" ?> /> Pozicija BH3 (brendiranje slajdera) </label></p>
      <p><label title="Poziija MBH3 (sredina)"><input type='checkbox' name='setup[bnr_MBH3]' value='1' <?= @$setup->bnr_MBH3 ? "checked='checked'":"" ?> /> Pozicija MBH3 (brendiranje na mobilnom)</label></p>
      <hr />
      <p><label title="Poziija PR1 (brendiranje PR-front)"><input type='checkbox' name='setup[bnr_PR1]' value='1' <?= @$setup->bnr_PR1 ? "checked='checked'":"" ?> /> Pozicija PR1 (PR-front) </label></p>
      <p><label title="Poziija PR2 (brendiranje PR-back)"><input type='checkbox' name='setup[bnr_PR2]' value='1' <?= @$setup->bnr_PR2 ? "checked='checked'":"" ?> /> Pozicija PR2 (PR-back)</label></p>
      <p><label title="Poziija MPR1 (brendiranje PR-back na mobilnom)"><input type='checkbox' name='setup[bnr_MPR1]' value='1' <?= @$setup->bnr_MPR1 ? "checked='checked'":"" ?> /> Pozicija MPR1 (PR-front na mobilnom)</label></p>
    </div>

    <p><input type=submit value='SNIMI'/></p>
  </form>
</div>
