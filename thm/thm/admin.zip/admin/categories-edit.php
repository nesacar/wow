<script type="text/javascript" src="<?= ATURI ?>js/tiny_mce/tiny_mce.js"></script >
<script type="text/javascript" src="<?= ATURI ?>js/tinymce-init.js"></script >

<h1>Izmena kategorije "<?= $cat['title'] ?>"</h1>
<div class='group' style='width:760px;'>
  <form method=post action="<?= AURI ?>category_save">
    <input type=hidden name='cid' value='<?= $cat['id'] ?>' />
    <table>
      <tr><td>Nadkategorija:</td>
        <td>
          <select name='cat[parent]'>
            <option value='0'>Bez nadkategorije (na vrhu)</option>
            <?php foreach($catList as $c) if($cat['id']!=$c['id']) echo "<option value='{$c['id']}' ".($cat['parent']==$c['id'] ? "selected='selected'":"").">{$c['pos']}. ".(empty($c['title']) ? "bez naslova":$c['title'])."</option>\n" ?>
          </select>
        </td>
      </tr>
      <tr><td>Pozicija u meniju:</td><td><input type=text name='cat[pos]' value='<?= $cat['pos'] ?>' required='required' /> <span class='tip'>(0 za skrivenu kategoriju)</span></td></tr>
      <tr><td>Istaknuta pozicija:</td><td><input type=text name='cat[hlpos]' value='<?= $cat['hlpos'] ?>' /> <span class='tip'>(0 za neistaknutu kategoriju)</span></td></tr>
      <tr><td>Naziv:</td><td><input type=text name='cat[title]' value='<?= $cat['title'] ?>' required='required' /></td></tr>

      <!-- tr><td>Vrsta prikaza:</td>
        <td>
          <select name='cat[catview]'>
            <?php foreach(@$views as $v) echo "<option value='{$v['id']}' ".($cat['catview']==$v['id'] ? "selected='selected'":"").">{$v['title']}</option>\n" ?>
          </select>
        </td>
      </tr-->

      <tr><td colspan=2><hr /><b>SEO:</b></td></tr>
      <tr><td>Meta title: </td><td><input type=text name='cat[meta_title]' value='<?= $cat['meta_title'] ?>'/></td></tr>
      <tr><td>Opis:</td><td><textarea name='cat[descr]'><?= $cat['descr'] ?></textarea></td></tr>
      <tr><td>Ključne reči:</td><td><input type=text name='cat[kwrds]'  value='<?= $cat['kwrds'] ?>'/></td></tr>
      <tr><td>Adresa (url):</td><td><input type=text name='cat[furl]' value='<?= $cat['furl'] ?>'/></td></tr>
      <tr><td valign='top'>Footer: </td><td><textarea rows='4' name='cat[footer]' class='contentEditor'><?= @$cat['footer'] ?></textarea></td></tr>
      <tr><td colspan=2><hr /></td></tr>
      <tr><td colspan=2><input type=submit value='Potvrdi'/></td></tr>
    </table>
  </form>
</div>