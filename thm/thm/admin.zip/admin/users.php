<h1>Lista korisnika</h1>
<table class='tblh' width=770 border="0" cellpadding="0" cellspacing="0">
<tr class='listtitle' ><th>Korisničko ime</th><th>Ime</th><th>e-mail</th><th>status</th><th>brisanje</th></tr>
<?php
$ustat = Array('owner'=>'vlasnik','admin'=>'urednik','writer'=>'novinar');
$i = 0;
foreach($users as $u) {
  $trc = ++$i % 2 ? "nepar":"par";
  echo "<tr class='{$trc}'><td><a href='".AURI."user_edit/{$u['id']}'>{$u['usr']}</td><td><a href='".AURI."user_edit/{$u['id']}'>{$u['name']}</a></td>"
      ."<td><a href='".AURI."user_edit/{$u['id']}'>{$u['email']}</td><td>{$ustat[$u['status']]}</td>"
      ."<td align=center>".($u['status']=='owner' ? "":"<a href='javascript:obrisiKorisnika({$u['id']})'>X</a>")."</td>"
      ."</tr>\n";
}
?>
</table>


<script type="text/javascript">
function obrisiKorisnika(uid){
  if(!confirm('Brisanje korisnika?')) return;
  $.post("<?= AURI ?>user_del",{uid:uid},function(data){window.location.reload()});
}
</script>