<div id='left'>
  <ul id='navlevo'>
    <?php if(false){ ?>
    <li><a href='<?= AURI ?>gdk'>Brendovi</a></li>
    <?php } ?>
    <li><a href='<?= AURI ?>gdk_dist'>Distributeri</a></li>
    <?php if(false){ ?>
    <li><a href='<?= AURI ?>gdk_cat'>Kategorije</a></li>
    <li><a href='<?= AURI ?>gdk_products'>Proizvodi</a></li>
    <li><a href='<?= AURI ?>gdk_stats'>Statistika</a></li>
    <li><a href='<?= AURI ?>gdk_catalogs'>Katalozi</a></li>
    <?php } ?>
    <li><a href='<?= AURI ?>gdk_settings'>Podešavanja</a></li>
  </ul>
</div>