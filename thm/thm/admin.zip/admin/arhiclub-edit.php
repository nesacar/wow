<h1>Arhi Club član: <?= $architect['title'] .' '. $architect['name'] .' '. $architect['surname'] ?></h1>
<div class="line"> </div>
<form method='post' enctype='multipart/form-data' action='<?= AURI ?>architect_save'>
  <input type=hidden name='architect[id]' value='<?= $architect['id'] ?>' />
  <table style='float:left; width: 770px;'>

    <tr><td style="width:100px">E-mail: </td><td><input style='width:250px;' type=text name='architect[email]' value='<?= $architect['email'] ?>' readonly /></td></tr>
    <tr><td>Lozinka: </td><td><input style='width:250px;' type='password' name='architect[pwd]' /></td></tr>
    <tr><td>Ime: </td><td><input style='width:250px;' type=text name='architect[name]' value='<?= $architect['name'] ?>' required='required' /></td></tr>
    <tr><td>Prezime: </td><td><input style='width:250px;' type=text name='architect[surname]' value='<?= $architect['surname'] ?>' /></td></tr>
    <tr><td>Godište: </td><td><input style='width:250px;' type=text name='architect[byear]' value='<?= $architect['byear'] ?>' /></td></tr>
    <tr><td>Grad: </td><td><input style='width:250px;' type=text name='architect[town]' value='<?= $architect['town'] ?>' /></td></tr>

    <tr><td colspan=2><div class="line"> </div></td></tr>
    <tr><td>Registrovan: </td><td><?= date("d.m.Y",strtotime($architect['joined'])) ?></td></tr>
    <tr><td>Status: </td><td>
      <select name='architect[status]' required='required'>
        <option value='active'>Aktivan</option>
        <option value='inactive' <?= $architect['status']=='inactive' ? "selected='selected'":"" ?>>Deaktiviran</option>
        <?php if($architect['status']=='deleted') echo "<option value='deleted' selected='selected'>Deleted</option>\n"; ?>
      </select>
  </table>


  <input type=submit name='save_and_stay' value='Save' />
  <input type="button" style='float:right; margin:10px 0 0 3px;' onClick="architectDelete()" value="Delete architect" />
  <input type=reset style='float:right' value='Cancel' />
</form>

<script type="text/javascript">
function architectDelete(){
	if(confirm('Brisanje člana?'))
	window.location.replace('<?= AURI ?>architect_delete/<?= $architect['id'] ?>');
}
</script>
