<?php if(empty($dist)) return; ?>
<h1>Micro Site distributera: <?= $dist['title'] ?></h1>

<div class='group' style='width:760px;'>
  <b><a href="<?= AURI ?>gdk_dist_view/<?= $dist['id'] ?>">NAZAD NA PREGLED</a></b>
</div>

<div class='group' style='width:760px;'>
  <form method="post">
    <input type='hidden' name='dist' value='<?= $dist['id'] ?>' />
    <label title="Omogući Micro Site"><input type='checkbox' name='ms_enable' value='1' <?= $dist['microsite'] ? "checked='checked'":"" ?> /> omogući Micro Site </label> &nbsp; | &nbsp;
    Naslov info strane: <input type='text' name='ms_title' value="<?= $dist['ms_title'] ?>" />
    <input type='submit' value='Potvrdi' />
  </form>

  <br />
  <b><a href='<?= AURI ?>microsite_edit?dist=<?= $dist['id'] ?>'>» Dodaj novu stranicu</a></b>
</div>

<?php if(!empty($pages)) { ?>
<div class='group' style='width:760px;'>
  <?php foreach($pages as $p) { ?>
    <div class='group'>
      <div class='top <?= $p['pos']==0 ? "invisible":"" ?>'>
        <a href='<?= AURI ?>microsite_edit/<?= $p['id'] ?>'>
          <?= $p['pos'] ?>. <?= empty($p['title']) ? "bez naslova":$p['title'] ?>
        </a>
        <div class='del'>
          <label title='Obriši'>
            <input type=button value='X' onClick="obrisi('<?= $p['id'] ?>')"/>
          </label>
        </div>
      </div>
      <div class='spacer0'></div>
    </div>
  <?php } ?>
</div>
<?php } ?>

<script type="text/javascript">
function obrisi(id) {
  if(!confirm('Brisanje stranice?')) return false;
  $.post("<?= AURI ?>microsite_delete", {id:id}, function(data){window.location.reload()});
}
</script>