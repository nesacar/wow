<?php if(empty($gdkCatLinks)) return; ?>
<?php foreach($gdkCatLinks as $gc) { ?>
  <input type="button" style="background-color:#666" value="<?= $gc['title'] ?>" onClick="gdkRemoveCatLink(<?= $gc['id'] ?>)" />
<?php } ?>