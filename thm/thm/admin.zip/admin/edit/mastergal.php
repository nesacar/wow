<script type='text/javascript'>
$(document).ready(function(){
  $('#mastergal-checker').html("<label><input type='checkbox' id='mastergal-checkbox' name='page[mastergal]' value='1' /> glavna galerija za model</label>");
  <?= empty($page['model']) ?  "" : "$('#mastergal-checker').show();\n"; ?>
  <?= empty($page['model']) || empty($page['contents']['mastergal']) ? "" : "$('#mastergal-checkbox').attr('checked',true);\n" ?>
});


$('#brand-selector').change(function(){$('#mastergal-checkbox').attr('checked',false); $('#mastergal-checker').fadeOut()});
$('#series-selector').change(function(){$('#mastergal-checkbox').attr('checked',false); $('#mastergal-checker').fadeOut()});
$('#model-selector').change(function(){
  if(this.value==0) {
    $('#mastergal-checkbox').attr('checked',false);
    $('#mastergal-checker').fadeOut();
  }
  else $('#mastergal-checker').fadeIn();
});

</script>