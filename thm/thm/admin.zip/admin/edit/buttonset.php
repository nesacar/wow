<input type=submit name='save_and_stay' value='Sačuvaj' />
<input type=submit name='save_and_return' value='Sačuvaj i vrati se' />
<input type=submit name='save_and_clone' value='Sačuvaj i kloniraj' />
<!-- input type=button style='background-color:#666' value='Izmeni tip' onClick="window.location.href='<?= AURI ?>page_chpgt/<?= $page['id'] ?>'" / -->
<input type=button style='background-color:#666' value='Pregled stranice' onClick="window.open('<?= Page::getLink($page) ?>', '_blank')" />

<input type="button" style='float:right; margin-left:3px;' onClick="pageDelete()" value="Brisanje stranice" />

<input type=reset style='float:right' value='Poništi izmene' />

<hr />

<script type="text/javascript">
function pageDelete(){
	if(confirm('Brisanje stranice?\nSlike povezane sa stranicom neće biti obrisane\n(mogu se naknadno obrisati u sekciji "Fajlovi").'))
	window.location.replace('<?= AURI ?>page_delete/<?= $page['id'] ?>');
}
</script>