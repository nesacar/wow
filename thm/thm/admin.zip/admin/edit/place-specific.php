<?php
if(empty($page)) return;
$fList = Filter::getList();
$pAttr = Filter::getPlaceAttrList($page['contents']['id']);

?>
<tr><td><b>Mesto:</b></td></tr>

<tr><td>Adresa: </td><td><input style='width:600px;' type='text' name='page[adr]' value='<?= $page['contents']['adr'] ?>'/></td></tr>
<tr><td>Telefon: </td><td><input style='width:600px;' type='text' name='page[tel]' value='<?= $page['contents']['tel'] ?>'/></td></tr>
<tr><td>Web: </td><td><input style='width:600px;' type='text' name='page[url]' value='<?= $page['contents']['url'] ?>'/></td></tr>

<tr><td>Filter: </td><td>
  <select name='page[filter]' onChange='chgFilter(this.value)'>
    <option value='0'>Bez filtera</option>
    <?php foreach($fList as $f) echo "<option value='{$f['id']}' ".($f['id']==$page['contents']['filter'] ? "selected='selected'":"").">{$f['title']}</option>\n"; ?>
  </select>
</td></tr>

<tr><td></td><td>
<input type='hidden' name='fattr_place_id' value='<?= $page['contents']['id'] ?>' />
<?php
foreach($fList as $f){
  $aList = Filter::getAttrList($f['id']);
  if(empty($aList)) continue;

  echo "<div class='attrList' id='attrList_{$f['id']}' style='display:".($f['id']==$page['contents']['filter'] ? "block":"none")."'>\n";

  foreach($aList as $a){
    echo "<label title='{$a['title']}'><input type='checkbox' name='attr[{$a['id']}]' value='1' ".(empty($pAttr[$a['id']]) ? "":"checked='checked'")." />{$a['title']}</label> &nbsp;&nbsp;&nbsp;\n";
  }

  echo "</div>\n";
}
?>
</td></tr>

<tr><td colspan=2><hr /></td></tr>


<script type="text/javascript">
function chgFilter(fid){
  $('.attrList').hide();
  $('#attrList_'+fid).show();
}
</script>

