<tr><td>Kategorija:</td>
  <td>
    <select name='page[cat]'>
      <option value='-1'>Ne pojavljuje se u vestima</option>
      <option value='0' <?= $page['cat']==0 ? "selected='selected'":"" ?>>Bez potkategorije u vestima</option>
      <?php
        foreach($catList as $c) {
          echo "<option value='{$c['id']}' ".($c['id']==$page['cat'] ? "selected='selected'":"").">{$c['pos']}. ".(empty($c['title']) ? "bez naslova":$c['title'])."</option>\n";
          if(!empty($c['sub'])) foreach ($c['sub'] as $s)
            echo "<option value='{$s['id']}' ".($s['id']==$page['cat'] ? "selected='selected'":"").">-- {$s['pos']}. ".(empty($s['title']) ? "bez naslova":$s['title'])."</option>\n";
        }
      ?>
    </select>
  </td>
</tr>

<tr><td style="width:90px;">Naslov:</td><td><input style='width:500px;' type=text name='page[title]' value='<?= $page['title'] ?>' required='required' /></td></tr>

<tr><td>Datum objave:</td><td><input type=text class='datum' name='page[published]' value='<?= date("Y-m-d",strtotime($page['published'])) ?>' required='required' />
<input type=text name='page[published_time]' value='<?= date("H:i",strtotime($page['published'])) ?>' />
</td></tr>

<tr><td>Komentari: </td><td><label title='Dozvoliti komentarisanje'><input type='checkbox' name='page[comments]' value='1' <?= $page['comments'] ? "checked='checked'":"" ?> /> komentarisanje je dozvoljeno</label></td></tr>
<!-- &nbsp; &nbsp; [<a href="<?= AURI ?>comments_review/<?= $page['id'] ?>">pregledaj komentare</a>]</td></tr> -->
<tr><td>Vidljivost: </td><td><label title='Članak je vidljiv'><input type='checkbox' name='page[visible]' value='1' <?= $page['visible'] ? "checked='checked'":"" ?> /> članak je vidljiv</label></td></tr>
<tr><td>Naslovna strana: </td><td><label title='Članak se prikazuje na naslovnoj strani'><input type='checkbox' name='page[frontpage]' value='1' <?= $page['frontpage'] ? "checked='checked'":"" ?> /> članak se prikazuje na naslovnoj strani</label></td></tr>

<tr>
  <td>Brend: </td>
  <td>
    <select name='page[brand]'>
      <option value='0'>Bez brenda</option>
      <?php foreach($brandList as $b) echo "<option value='{$b['id']}' ".($b['id']==$page['brand'] ? "selected='selected'":"").">{$b['title']}</option>\n"; ?>
    </select>
  </td>
</tr>
