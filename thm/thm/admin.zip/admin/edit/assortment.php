<?php if(empty($assortmentList)) return; ?>

<p><b>Asortiman:</b></p>

<div style="column-count: 3; -moz-column-count: 3; -webkit-column-count: 3; column-gap: 30px; -moz-column-gap: 30px; -webkit-column-gap: 30px">
<?php foreach($assortmentList as $a) { ?>
  <div style="width: 220px; margin-bottom: 15px; display: inline-block">
    <b><label title="<?= $a['title'] ?>"><input type='checkbox' name='asl[]' id='asl_parent_<?= $a['id'] ?>' value='<?= $a['id'] ?>' <?= @in_array($a['id'], $assortmentLinks) ? "checked='checked'" : "" ?> onClick="$('.asl_sub_<?= $a['id'] ?>').attr('checked',this.checked)" /><?= $a['title'] ?></label></b>
    <?php if(!empty($a['sub'])) { ?>
      <br />
      <?php foreach($a['sub'] as $s) { ?>
        &bull; <label title="<?= $s['title'] ?>"><input type='checkbox' name='asl[]' class='asl_sub_<?= $a['id'] ?>' value='<?= $s['id'] ?>' <?= @in_array($s['id'], $assortmentLinks) ? "checked='checked'" : "" ?> onClick="if(this.checked) $('#asl_parent_<?= $a['id'] ?>').attr('checked',true)" /><?= $s['title'] ?></label><br />
      <?php } ?>
    <?php } ?>

  </div>
<?php } ?>
</div>