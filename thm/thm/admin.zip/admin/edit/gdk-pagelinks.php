<b>GDK kategorije:</b>&nbsp;
<select id="gdk-cat-sel">
  <option value=''>Odaberite kategoriju...</option>
  <?php
    foreach($gdkCatList as $gc) {
      echo "<option value='{$gc['id']}'>{$gc['title']}</option>\n";
      if(!empty($gc['sub'])) foreach($gc['sub'] as $gcs) echo "<option value='{$gcs['id']}'>-- {$gcs['title']}</option>\n";
    }
  ?>
</select>
<input type="button" value="Dodaj" onClick="gdkAddCatLink()" style="background-color:#666" />

<div id="gdk-cat-links">
  <?php include "gdk-pagelinks-list.php"; ?>
</div>
<div class='spacer10'></div>
<hr />

<script type="text/javascript">
function gdkAddCatLink() {
  $.post("<?= AURI ?>page_catlink",{action:'add',pid:'<?= @$page['id'] ?>',gcid:$('#gdk-cat-sel').val()},function(data){$('#gdk-cat-links').html(data)});
}
function gdkRemoveCatLink(gcid) {
  $.post("<?= AURI ?>page_catlink",{action:'remove',pid:'<?= @$page['id'] ?>',gcid:gcid},function(data){$('#gdk-cat-links').html(data)});
}
</script>