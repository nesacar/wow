<?php if(empty($page)) return; ?>
<tr><td colspan=2><hr /><b>SEO:</b></td></tr>

<tr><td valign='top'>Opis:<br />(<span id='opis_cct'><?= (int)(170-strlen(@$page['descr'])) ?></span>)</td><td valign='top'>
  <textarea style='width:500px; font-size:12px; font-family: Arial,Helvetica,sans-serif;' name='page[descr]' onkeyup="izbroj_cct(this,170,'opis_cct')"><?= @$page['descr'] ?></textarea>
</td></tr>

<tr><td valign='top'>RSS tekst:<br />(<span id='rssbody_cct'><?= (int)(450-strlen(@$page['rssbody'])) ?></span>)</td><td valign='top'>
  <textarea style='width:500px; height: 60px; font-size:12px; font-family: Arial,Helvetica,sans-serif;' name='page[rssbody]' onkeyup="izbroj_cct(this,450,'rssbody_cct')"><?= @$page['rssbody'] ?></textarea>
</td></tr>

<tr><td valign='top'>Ključne reči:</td><td valign='top'><input style='width:500px;' type=text name='page[kwrds]'  value='<?= @$page['kwrds'] ?>'/></td></tr>
<tr><td>Adresa (url):</td><td><input style='width:500px;' type=text name='page[furl]' value='<?= @$page['furl'] ?>'/></td></tr>

<tr><td colspan=2><hr /></td></tr>
<input type='hidden' name='page[old_furl]' value='<?= @$page['furl'] ?>' />

<script type="text/javascript">
function izbroj_cct(elem,mct,infospan){
  var ct = elem.value.length;
  if(ct > mct){
    elem.value = elem.value.substr(0,mct);
    $('#'+infospan).html('0');
  }
  else $('#'+infospan).html(mct-ct);
}
</script>