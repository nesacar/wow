<?php if(empty($page)) return; ?>

<table style='float:left; width: 274px;'>
  <tr><td align=left>Naslovna fotografija (600x400):</td></tr>
  <tr><td align=left><input type=file name='timg' style='width:274px;' /></td></tr>
  <tr><td align=left>
    <div style='width:188px; height: 128px; background-color: #F00; border: 1px solid #888'><div style='width:180px; height: 120px; border: 4px solid white;'>
      <?php if(!empty($page['timg'])) echo "<img src=\"".SURI."image.php/".basename($page['timg'])."?width=180&height=120&image=".SURI.$page['timg']."\" />"; ?>
    </div></div>
  </td></tr>
</table>

<table style='float:left; width: 200px; margin-left: 20px'>
  <tr><td align=left>Crop naslovne za slajder:</td></tr>
  <tr><td>
    <select name='page[simg_croppos]'>
      <option value=''>Ne prikazuj u slajderu</option>
      <?php foreach(array("top"=>"Top","top_half"=>"25% top","center"=>"Middle","bottom_half"=>"25% bottom","bottom"=>"Bottom") as $cp=>$cpS) echo "<option value='{$cp}' ".($cp==$page['simg_croppos'] ? "selected='selected'":"").">{$cpS}</option>\n"; ?>
    </select>
  </td></tr>
  <?php if(!empty($page['timg']) && !empty($page['simg_croppos'])) { ?>
  <tr><td align=left>
    <div style='width:200px; height: 108px; background-color: #F00; border: 1px solid #888'><div style='width:192px; height: 100px; border: 4px solid white;'>
      <img src="<?= SURI ?>image.php/<?= basename($page['timg']) ?>?width=192&height=100&cropratio=192:100&cropposition=<?= $page['simg_croppos'] ?>&image=<?= SURI.$page['timg'] ?>" />
    </div></div>
  </td></tr>
  <?php } ?>
</table>

<table style='float:left; width: 200px; margin-left: 20px'>
  <tr><td align=left>Widget foto (300x250) i naslov:</td></tr>
  <tr><td align=left><input type=file name='wimg' style='width:188px;' /></td></tr>
  <tr><td align=center>
    <div style='width:128px; height: 108px; background-color: #F00; border: 1px solid #888'><div style='width:120px; height: 100px; border: 4px solid white;'>
      <?php if(!empty($page['wimg'])) echo "<img src=\"".SURI."image.php/".basename($page['wimg'])."?width=120&height=100&image=".SURI.$page['wimg']."\" />"; ?>
    </div></div>
  </td></tr>
  <tr><td>
    <input style='width: 188px;' placeholder='Naslov u widget-u' type=text name='page[wtitle]' value='<?= $page['wtitle'] ?>' />
  </td></tr>
  <?php if(!empty($page['wimg'])) { ?>
    <tr><td><label title='Ukloni iz widget-a'><input type='checkbox' name='page[widget-remove]' value='1' />Ukloni iz widget-a</label></td></tr>
  <?php } ?>

</table>
<div style="clear: both;"></div>
<div><input type='checkbox' name='page[himg]' value='1'  <?= $page['himg'] ? "checked='checked'":"" ?>/> Prikazuje se u tekstu
  <div class="spacer10"></div>
</div>

<div class='spacer10'></div>
<hr />