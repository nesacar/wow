<h1>Promena tipa stranice</h1>
<div class='infobox'>
<p><b>Napomena: </b></p>
<p>Promena tipa (šablona) stranice može dovesti do gubitka specifičnih podataka.</p>
</div>
<div class='group'>
  <form method=post action="<?= AURI ?>page_updatepgt">
    <input type='hidden' name='pid' value='<?= $page['id'] ?>' />
    <table>
      <tr><td>Naslov: </td><td><?= $page['title'] ?></td></tr>
      <tr><td>Trenutni tip: </td><td><?= $pgt['title'] ?></td></tr>
      <tr><td>Novi tip: </td>
        <td>
          <select name='new_pgt'>
            <?php
              foreach($pgtL as $p) if($p['id']!=$pgt['id']) echo "<option value='{$p['id']}'>{$p['title']}</option>\n";
            ?>
          </select>
        </td>
      </tr>

      <tr><td colspan=2><input type=submit value='Potvrdi'/></td></tr>
    </table>
  </form>
</div>