<script type="text/javascript" src="<?= ATURI ?>js/tiny_mce/tiny_mce.js"></script >
<script type="text/javascript" src="<?= ATURI ?>js/tinymce-init.js"></script >

<h1><?= empty($dist) ? "Novi distributer" : "Izmena distributera: ".$dist['title'] ?></h1>
<div class='group' style='width:760px;'>
  <form method=post enctype='multipart/form-data' action="<?= AURI ?>gdk_dist_save">
    <input type=hidden name='dist[id]' value='<?= @$dist['id'] ?>' />
    <input type=hidden name='dist[old_furl]' value='<?= @$dist['furl'] ?>' />

    <table width="100%">
      <tr><td>Naziv: </td><td><input type=text name='dist[title]' value='<?= @$dist['title'] ?>' required='required' /></td></tr>
      <tr><td>Status:</td><td><label title='Distributer je aktivan'><input type='checkbox' name='dist[active]' value='1' <?= @$dist['active'] ? "checked='checked'":"" ?> /> distributer je aktivan</label></td></tr>
      <tr><td>E-mail: </td><td><input type=text name='dist[email]' value='<?= @$dist['email'] ?>' /></td></tr>
      <tr><td>Sajt: </td><td><input type=text name='dist[url]' value='<?= @$dist['url'] ?>' /></td></tr>
      <tr><td>Username: </td><td><input type=text name='dist[usr]' value='<?= @$dist['usr'] ?>' required='required' /></td></tr>
      <tr><td>Password: </td><td><input type=password name='dist[pwd]' /></td></tr>
      <tr><td>Limit broja proizvoda: </td><td><input type=text name='dist[plimit]' value='<?= @$dist['plimit'] ?>' /></td></tr>
      <tr><td>Značaj (za sortiranje): </td><td><input type=text name='dist[weight]' value='<?= @$dist['weight'] ?>' /></td></tr>

      <tr><td colspan=2><hr /><b>SEO:</b> </td></tr>
      <tr><td>Opis: </td><td><textarea name='dist[descr]'><?= @$dist['descr'] ?></textarea></td></tr>
      <tr><td>Ključne reči: </td><td><input type=text name='dist[kwrds]'  value='<?= @$dist['kwrds'] ?>'/></td></tr>
      <tr><td>Adresa (url): </td><td><input type=text name='dist[furl]' value='<?= @$dist['furl'] ?>'/></td></tr>
      <tr><td colspan=2><hr /></td></tr>

      <tr><td colspan=2><textarea name='dist[html]' class='contentEditor' style='width:100%; height:200px'><?= @$dist['html'] ?></textarea></td></tr>

      <tr><td colspan=2><hr /><?php include "edit/assortment.php"; ?></td></tr>

      <tr><td colspan=2><hr /><b>Brendovi:</b> </td></tr>



      <tr>
        <td colspan=2>
        <?php foreach($brandList as $b) { ?>
          <div style="width: 220px; float: left; margin-right: 30px;">
            <label title="<?= $b['title'] ?>"><input type='checkbox' name='dist_brand[]' value='<?= $b['id'] ?>' <?= in_array($b['id'], $dist['brands']) ? "checked='checked'" : "" ?> /><?= $b['title'] ?></label>
          </div>
        <?php } ?>
        </td>
      </tr>

      <tr><td colspan=2><hr /></td></tr>

      <tr><td>Logotip (118x118): </td><td><input type=file name='logo' /></td></tr>
      <tr><td colspan=2>
        <?php if(!empty($dist)) { ?>
          <div style='width:126px; height: 126px; background-color: #F00; border: 1px solid #888'><div style='width:118px; height: 118px; border: 4px solid white;'>
          <?php if(!empty($dist['logo'])) echo "<img src=\"".SURI."image.php/".basename($dist['logo'])."?width=118&height=118&image=".SURI.$dist['logo']."\" />"; ?>
          </div></div>
        <?php } ?>
      </td></tr>

      <tr><td colspan=2><hr /></td></tr>

      <tr><td colspan=2><input type=submit value='Potvrdi'/></td></tr>
    </table>
  </form>
</div>