<h1>Novi korisnik</h1>
<div class='group' style='width:420px;'>
  <form method=post action="<?= AURI ?>user_save">
    <table>
      <tr><td>Korisnik: </td><td><input type=text name='name' /></td></tr>
      <tr><td>Korisničko ime: </td><td><input type=text name='usr' required='required' /></td></tr>
      <tr><td>Lozinka: </td><td><input type=password name='pwd' required='required' /></td></tr>
      <tr><td>E-mail: </td><td><input type=text name='email' /></td></tr>
      <tr><td>Pristup: </td><td><select name='status'><option value='writer'>Novinar</option><option value='admin'>Urednik</option></select>

      <tr><td colspan=2><input type=submit value='SNIMI'/></td></tr>
    </table>
  </form>
</div>