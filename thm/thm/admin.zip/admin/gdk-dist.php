<h1>GDK UREĐIVANJE DISTRIBUTERA</h1>

<div class='group'>
  <b><a href='<?= AURI ?>gdk_dist_edit'>» Dodaj novog distributera</a></b>
</div>

<?php foreach($distList as $d){ ?>
  <div class='group'>
    <div class='top <?= $d['active']==0 ? "invisible":"" ?>'>
      <a href='<?= AURI ?>gdk_dist_view/<?= $d['id'] ?>'>
        <?php if(!empty($d['logo'])) echo "<img src=\"".SURI."image.php/".basename($d['logo'])."?width=30&height=30&image=".SURI.$d['logo']."\"  style='vertical-align:middle' /> &nbsp; "; ?>
        <?= empty($d['title']) ? "bez naziva":$d['title'] ?>
      </a>
      <div class='del'>
        <label title='Obriši'>
          <input type=button value='X' onClick="obrisi('<?= $d['id'] ?>')"/>
        </label>
      </div>
    </div>
    <div class='spacer0'></div>
  </div>
<?php } ?>


<script type="text/javascript">
function obrisi(id) {
  if(!confirm('Brisanje distributera?\nUkoliko obrišete distributera svi njegovi proizvodi će postati nevidljivi!\n\nNajbolje je da distributera označite kao "neaktivan".\n\n')) return false;
  $.post("<?= AURI ?>gdk_dist_del", {did:id}, function(data){window.location.reload()});
}
</script>

<div class='spacer10'></div>
