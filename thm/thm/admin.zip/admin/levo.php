<div id='left'>
<ul id='navlevo'>
  <li><a href='<?= AURI ?>page_new'><img width="16" height="16" src="<?= ATURI ?>images/novastrana.png">NOVI ČLANAK</a></li>
  <li><a href='<?= AURI ?>pages'><img width="16" height="16" src="<?= ATURI ?>images/clanci.png">LISTA ČLANAKA</a></li>
  <li><a href='<?= AURI ?>banners'><img width="16" height="16" src="<?= ATURI ?>images/banneri.png">BANERI</a></li>
  <li><a href='<?= AURI ?>filebrowser'><img width="16" height="16" src="<?= ATURI ?>images/fajlovi.png">FAJLOVI</a></li>
  <li><a href='<?= AURI ?>settings'><img width="16" height="16" src="<?= ATURI ?>images/settings.png">BANERI</a></li>
</ul>
</div>