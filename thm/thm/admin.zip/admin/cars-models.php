<h1>Lista modela</h1>
<div class='group' style='width:757px;'>
  Brend:
  <select id='brand_select' onChange="selectBrand(this.value)">
    <option value='-1'>Odaberite brend</option>
    <option value='0'>Serije bez brenda</option>
    <?php foreach($brandList as $b) echo "<option value='{$b['id']}'>{$b['title']}</option>\n"; ?>
  </select>

  <select id='series_select' onChange="selectSeries(this.value)">
    <option value='-1'>Odaberite seriju</option>
    <option value='0'>Modeli bez serije</option>
  </select>

</div>

<div id='model_list'>
  <?php include "cars-models-list.php"; ?>
</div>

<script type="text/javascript">
function obrisiModel(id) {
  if(!confirm('Brisanje modela?\nUkoliko obrišete model svi motori će postati nedostupni!\n\nAdministrator mora da interveniše za povraćaj kategorizacije.\nADMIN: Nikola Ivković, 063 230 191 ili nikola.ivkovic@weboperater.rs')) return false;
  $.post("<?= AURI ?>car_model_del", {mid:id}, function(data){selectSeries($('#series_select').val())});
}
</script>

<script type="text/javascript">
function selectBrand(bid){
  $.post("<?= SURI ?>fillSelector",{selector:'series',parent:bid,includeDisabled:true},function(data){$('#series_select option:gt(1)').remove();$('#series_select').append(data)});
}

function selectSeries(sid){
  $.post("<?= AURI ?>/car_models_list",{series:sid},function(data){$("#model_list").html(data)});
}
</script>