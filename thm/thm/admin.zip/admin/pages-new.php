<h1>Novi članak</h1>
<div class='group'>
  <form method=post action="<?= AURI ?>page_create">
    <table>
      <tr><td>Tip sadržaja</td>
        <td>
          <select name='page[pgt]'>
            <?php
              foreach($pgtL as $p) echo "<option value='{$p['id']}'>{$p['title']}</option>\n";
            ?>
          </select>
        </td>
      </tr>

      <tr><td>Kategorija:</td>
        <td>
          <select name='page[cat]'>
          	<option value='0'>Bez kategorije</option>
            <?php
              foreach($catList as $c) {
                echo "<option value='{$c['id']}'>{$c['pos']}. ".(empty($c['title']) ? "bez naslova":$c['title'])."</option>\n";
              }
            ?>
          </select>
        </td>
      </tr>
      <tr><td>Naslov:</td><td><input type=text name='page[title]' required='required' /></td></tr>
      <tr><td>Komentari:</td><td><label title='Dozvoliti komentarisanje'><input type='checkbox' checked='checked' name='page[comments]' value='1' /> komentarisanje je dozvoljeno</label></td></tr>

      <tr><td colspan=2><input type=submit value='Potvrdi'/></td></tr>
    </table>
  </form>
</div>