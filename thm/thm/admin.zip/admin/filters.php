<h1>Filteri</h1>
<div class='group' style='width: 760px'>
  <form method="post" enctype='multipart/form-data' action="<?= AURI ?>filter_new">
    Novi filter: <input type='text' name='ftitle'  required='required' /> &nbsp; sličica (24x24): <input type='file' name='img' /> <input type='submit' value='Potvrdi' />
  </form>

  <?php if(!empty($fList)) { ?>
    <form method="post" action="<?= AURI ?>fattr_new">
      Novi atribut za filter <select name='id_f'><?php foreach($fList as $f) echo "<option value='{$f['id']}'>{$f['title']}</option>" ?></select>: <input type='text' name='fatitle'  required='required' /> <input type='submit' value='Potvrdi' />
    </form>
  <?php } ?>

</div>

<div class='spacer10'></div>
<h2>Filteri u upotrebi:</h2>

<?php if(!empty($fList)) foreach($fList as $f) {
  $sub = Filter::getAttrList($f['id']);
?>
<div class='group'>
  <div class='top'>
    <a href='<?= AURI ?>filter_edit/<?= $f['id'] ?>'><?= empty($f['img']) ? "" : "<img src='".SURI.$f['img']."' width='24' height='24' /> "?><?= $f['title'] ?></a>
    <div class='del'>
      <label title='Obriši'>
        <input type=button value='X' onClick="del_filter('<?= $f['id'] ?>')"/>
      </label>
    </div>
  </div>

  <?php if(!empty($sub)) foreach($sub as $s) { ?>
    <div class='sub'>
      <div class='top'>
        <?= $s['title'] ?>
        <div class='del'>
          <label title='Obriši'>
            <input type=button value='X' onClick="del_fattr('<?= $s['id'] ?>')"/>
          </label>
        </div>
      </div>
    </div>
  <?php } ?>
  <div class='spacer0'></div>


</div>


<?php } ?>

<script type="text/javascript">
function del_filter(id){
  if(!confirm('Brisanje filtra?')) return false;
  $.post("<?= AURI ?>filter_del", {del:'filter',id:id}, function(data){window.location.reload()});
}
function del_fattr(id){
  if(!confirm('Brisanje atributa?')) return false;
  $.post("<?= AURI ?>filter_del", {del:'fattr',id:id}, function(data){window.location.reload()});
}
</script>
