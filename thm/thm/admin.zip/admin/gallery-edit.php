<?php

if(!is_dir($gPath)) {
?>
  u sekciji "FAJLOVI" u folderu <br />
  <b>chest/<?= $pgt['gfolder'] ?></b><br />
  kreirajte podfolder <br />
  <b><?= $page['furl'] ?></b><br />
  i u njega upload-ujte
  željeni broj slika veličine 600x400 piksela (ili većih u razmeri 3:2)<br /><br />
<?php

} else {
  $w = 600; $h=400; $r = $w/$h;

  $arr = scandir($gPath);


  echo "<div style='height: 360px; overflow: auto;'>";
  echo "<form id='gallery_edit_form' onSubmit='return false'>";
  echo "<input type='hidden' name='pid' value='{$page['id']}' />";

  $toCrop = false;
  $i_found = 0;
  foreach($arr as $a) {
    $info = @getimagesize($gPath.$a);
    if(empty($info)) continue;
    $i_found++;

    // Jedna od dimenzija slike je premala:
    if($info[0] < $w || $info[1] < $h){
      lg_print_small($gURI,$a);
      continue;
    }
    // Velicina je ok:
    if($info[0]==$w && $info[1]==$h) {
      lg_print_ok($gURI,$a);
      continue;
    }

    $ratio = $info[0] / $info[1];
    // Velicina nije ok, ali ratio w/h jeste:
    if($ratio == $r) {
      $src = str_replace(" ","%20",SURI."image.php?image={$gURI}{$a}&width=600");
      $dst = "{$gPath}{$a}";
      copy($src,$dst);
      lg_print_ok($gURI,$a);
    }

    // Slika je sira od 3:2...
    elseif($ratio > $r){
      lg_print_w($gURI,$a);
      $toCrop = true;
    }
    // Slika je uza od 3:2...
    else {
      lg_print_h($gURI,$a);
      $toCrop = true;
    }

  }

  if($toCrop){
    echo "<div style='clear:both'><input type=button value='Potvrdi izmene' onclick='gallery_img_crop()' /></div>";
  }
  if($i_found==0){
    echo "<p>u sekciji \"FAJLOVI\" u folder<br /><b>chest/{$pgt['gfolder']}/{$page['furl']}</b><br />upload-ujte željeni broj slika veličine 600x400 piksela (ili većih u razmeri 3:2)</p>";
  }

  echo "</form>";
  echo "</div>";


}
?>




<?php
function lg_print_ok($uriPref,$img){
  echo "<div style='clear:both;'>
          <img style='float:left; width: 150px; margin-bottom: 10px' src='{$uriPref}{$img}' />
          <div style='float:left; padding: 10px;'>
  			{$img} <br />
  			Slika je OK
  		  </div>
        </div>
  ";
}
function lg_print_small($uriPref,$img){
  echo "<div style='clear:both;'>
          <img style='float:left; width: 150px; margin-bottom: 10px' src='{$uriPref}{$img}' />
          <div style='float:left; padding: 10px;'>
  			{$img} <br />
  			Slika je premala za opsecanje
  		  </div>
        </div>
  ";
}
function lg_print_w($uriPref,$img){
  $ii = md5($img);
  echo "<div style='clear:both'>
  		  <img id='{$ii}' style='float:left; width: 150px; margin-bottom:10px' src='".SURI."image.php?image={$uriPref}{$img}&width=150&cropratio=3:2' />
  		  <div style='float:left; padding: 10px;'>
  		    Slika je preširoka... <br />
  		    <select name='crop[{$ii}]' onChange=\"set_gal_img_croppos('{$ii}','{$uriPref}{$img}',this.value)\">
  		      <option value=''>Odaberite poziciju isecanja: </option>
  		      <option value='left'>Levo</option>
  		      <option value='left_half'>25% levo</option>
  		      <option value='center'>Sredina</option>
  		      <option value='right_half'>25% desno</option>
  		      <option value='right'>Desno</option>
  		    </select>
  		  </div>
  		</div>
  ";
}
function lg_print_h($uriPref,$img){
  $ii = md5($img);
  echo "<div style='clear:both'>
  		  <img id='{$ii}' style='float:left; width: 150px; margin-bottom:10px' src='".SURI."image.php?image={$uriPref}{$img}&width=150&cropratio=3:2' />
  		  <div style='float:left; padding: 10px;'>
  		    Slika je previsoka... <br />
  		    <select name='crop[{$ii}]' onChange=\"set_gal_img_croppos('{$ii}','{$uriPref}{$img}',this.value)\">
  		      <option value=''>Odaberite poziciju isecanja: </option>
  		      <option value='top'>Vrh</option>
  		      <option value='top_half'>25% gore</option>
  		      <option value='center'>Sredina</option>
  		      <option value='bottom_half'>25% dole</option>
  		      <option value='bottom'>Dno</option>
  		    </select>
  		  </div>
  		</div>
  ";
}


?>
