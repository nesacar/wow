<div>
Broj članaka: <?= $aCnt ?>
<table class='tblh' width=770 border="0" cellpadding="0" cellspacing="0">
<tr class='listtitle' >
  <?php if($session->status=='admin' || $session->status=='owner') { ?><th width=64>KREIRAN</th><?php } ?>
  <th width=64>OBJAVA</th>
  <th>NAZIV ČLANKA</th>
  <th>KATEGORIJA</th>
  <th>X</th>
</tr>
<?php
$i = 0;
foreach($pList as $p) {
  $trc = ++$i % 2 ? "nepar":"par";
  if($p['visible']==0) $trc = "invisible";
  $cNames[-1] = 'ne pojavljuje se'; $cNames[0] = 'bez kategorije';
  $cat = empty($cNames[$p['cat']]) ? "-" : $cNames[$p['cat']];

  $showDel = true;
  if($_SESSION['user']['status']=='writer') {
    if($p['author']!=$_SESSION['user']['id']) $showDel = false;
    if($p['created'] < date("Y-m-d",strtotime("-1 week"))) $showDel = false;
  }

  echo "<tr class='{$trc}'>".($session->status=='admin' || $session->status=='owner' ? "<td>".date("d.m.Y",strtotime($p['created']))."</td>":"")
      ."<td>".date("d.m.Y",strtotime($p['published']))."</td>"
      ."<td><a href='".AURI."page_edit/{$p['id']}'>{$p['title']}</a></td>"
      ."<td>{$cat}</td>\n"
      .($showDel ? "<td align='center'><a href='".AURI."page_delete/{$p['id']}' onClick=\"return confirm('Brisanje stranice?')\" title='Brisanje stranice'>X</a></td>":"<td></td>")."</tr>\n";
}
?>
</table>
</div>

<?php
if($pCnt > 1){
  echo "<div class='group' style='width:755px;'>\n";
  if($pNum == 1) echo "« PREDHODNA | <b>1</b> | ";
  else {
    echo "<a href=\"javascript:setPage('".($pNum-1)."')\">« prethodna</a> | ";
    echo "<a href=\"javascript:setPage(1)\">1</a> | ";

    if($pNum > 2) echo " ... | <b>{$pNum}</b> | ";
    else echo " <b>2</b> | ";

  }
  if($pCnt > $pNum+1) echo "... | ";
  if($pNum == $pCnt) echo " sledeća »";
  else {
    echo "<a href=\"javascript:setPage('{$pCnt}')\">{$pCnt}</a> | ";
    echo "<a href=\"javascript:setPage('".($pNum+1)."')\">SLEDEĆA »</a>";
  }
?>
<div style='float:right'>STRANA:
<input type=text id='jump_to_page' style='width:16px;text-align:right' onkeydown="if(event.which==13) setPage(0)" />
<a href="javascript:setPage(0)">IDI »</a>
</div>
</td></tr>
<?
} // end if($page_count>1);
?>
