<div style='float: left; width: 375px; margin-right: 10px;'>

  <h1>UREĐIVANJE BRENDOVA</h1>

  <div class='group'>
    <b><a href='<?= AURI ?>gdk_brand_new'>» Dodaj novi brend</a></b>
  </div>

  <?php foreach($brandList as $b) { ?>
    <div class='group'>
      <div class='top <?= $b['visible']==0 ? "invisible":"" ?>'>
        <a href='<?= AURI ?>gdk_brand_edit/<?= $b['id'] ?>'>
          <?php if(!empty($b['logo'])) echo "<img src=\"".SURI."image.php/".basename($b['logo'])."?width=30&height=30&image=".SURI.$b['logo']."\"  style='vertical-align:middle' /> &nbsp; "; ?>
          <?= empty($b['title']) ? "bez naslova":$b['title'] ?>
        </a>
        <div class='del'>
          <label title='Obriši'>
            <input type=button value='X' onClick="obrisi('<?= $b['id'] ?>')"/>
          </label>
        </div>
        <input type='text' style='float: right; width: 72px; text-align: center; margin-right: 10px' onFocus="select()" onClick="select()" value="<?= $b['id'] ?>" readonly />
      </div>
      <div class='spacer0'></div>
    </div>
  <?php } ?>

  <div class='spacer10'></div>

</div>

<div style='float:left; width: 374px; padding-left: 10px; border-left: 1px solid #666'>
  <h1>KATEGORIZACIJA ASORTIMANA</h1>

  <div class='group'>
    <b><a href='<?= AURI ?>gdk_assortment_edit'>» Dodaj novu kategoriju asortimana</a></b>
  </div>

  <?php foreach($assortmentList as $a){ ?>
    <div class='group'>
      <div class='top'>
        <a href='<?= AURI ?>gdk_assortment_edit/<?= $a['id'] ?>'>
          <?= $a['pos'].". ".(empty($a['title']) ? "bez naslova":$a['title']) ?>
        </a>
        <div class='del'>
          <label title='Obriši'>
            <input type=button value='X' onClick="obrisiAssortment('<?= $a['id'] ?>')"/>
          </label>
        </div>
      </div>
      <?php if(!empty($a['sub'])) foreach($a['sub'] as $s) { ?>
        <div class='sub'>
          <div class='top'>
            <a href='<?= AURI ?>gdk_assortment_edit/<?= $s['id'] ?>'>
              <?= $s['pos'].". ".(empty($s['title']) ? "bez naslova":$s['title']) ?>
            </a>

            <div class='del'>
              <label title='Obriši'>
                <input type=button value='X' onClick="obrisiAssortment('<?= $s['id'] ?>')"/>
              </label>
            </div>
          </div>
        </div>
      <?php } ?>

      <div class='spacer0'></div>
    </div>
  <?php } ?>

</div>


<script type="text/javascript">
function obrisi(id) {
  if(!confirm('Brisanje brenda?\nUkoliko obrišete brend sve serije i modeli će postati nevidljivi i neće se prikazivati na sajtu!\n\nNajbolje je da brend označite kao "nevidljiv" - tada se neće prikazivati na sajtu.\n\nAdministrator mora da interveniše za povraćaj kategorizacije.\nADMIN: Nikola Ivković, 063 230 191 ili nikola.ivkovic@weboperater.rs')) return false;
  $.post("<?= AURI ?>gdk_brand_del", {bid:id}, function(data){window.location.reload()});
}
function obrisiAssortment(id) {
  if(!confirm('Brisanje kategorije asortimana')) return false;
  $.post("<?= AURI ?>gdk_assortment_del", {aid:id}, function(data){window.location.reload()});
}
</script>