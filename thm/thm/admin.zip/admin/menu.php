<script type="text/javascript">function odjava(){$("#_lof").trigger('submit');}</script>
<form id='_lof' style='display:none' method='post'><input type='hidden' name='action' value='logout'/></form>
<ul id='nav'>
	<li style=" margin:0!important; padding:0;"><a style=" margin:0!important; padding:0;" href="<?= AURI ?>"><img width="95" height="27" src="<?= ATURI ?>images/logo.png" alt="<?= $setup->main_title ?>"></a></li>
	<li><a href="<?= AURI ?>pages"><img width="16" height="16" src="<?= ATURI ?>images/kategorije.png">ČLANCI</a></li>
	<?php if($session->status=='admin' || $session->status=='owner') { ?><li><a href="<?= AURI ?>banners"><img width="16" height="16" src="<?= ATURI ?>images/banneri.png">BANERI</a></li><?php } ?>
	<li><a href="<?= AURI ?>gdk"><img width="16" height="16" src="<?= ATURI ?>images/kategorije.png">GDK</a></li>
  <?php if($session->status!='owner') { ?><li><a href="<?= AURI ?>arhiclub_settings"><img width="16" height="16" src="<?= ATURI ?>images/settings.png">ARHI CLUB</a></li><?php } ?>
	<?php if($session->status=='admin' || $session->status=='owner') { ?><li><a href="<?= AURI ?>newsletter"><img width="16" height="16" src="<?= ATURI ?>images/banneri.png">NewsLetter</a></li><?php } ?>
	<?php if($session->status=='owner') { ?><li><a href="<?= AURI ?>users"><img width="16" height="16" src="<?= ATURI ?>images/settings.png">Korisnici</a></li><?php } ?>
	<li><a href="<?= AURI ?>filebrowser"><img width="16" height="16" src="<?= ATURI ?>images/fajlovi.png">FAJLOVI</a></li>
	<li><a href="<?= SURI ?>" target="_blank"><img width="16" height="16" src="<?= ATURI ?>images/sajt.png">SAJT</a></li>

	<li class='desno'><a href="javascript:odjava()"><img width="16" height="16" src="<?= ATURI ?>images/logout.png">ODJAVA</a></li>
	<li class='desno'><a href="<?= AURI ?>settings"><img width="16" height="16" src="<?= ATURI ?>images/settings.png">PODEŠAVANJA</a></li>
</ul>