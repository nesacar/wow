<script type="text/javascript" src="<?= ATURI ?>js/tiny_mce/tiny_mce.js"></script >
<script type="text/javascript" src="<?= ATURI ?>js/tinymce-init.js"></script >

<h1><?= empty($brand) ? "Novi brend" : "Izmena brenda: ".$brand['title'] ?></h1>
<div class='group' style='width:760px;'>
  <form method=post enctype='multipart/form-data' action="<?= AURI ?>gdk_brand_save">
    <input type=hidden name='bid' value='<?= @$brand['id'] ?>' />
    <table width="100%">
      <tr><td>Naziv: </td><td><input type=text name='brand[title]' value='<?= @$brand['title'] ?>' required='required' /></td></tr>

      <tr><td>Vidljivost:</td><td><label title='Brend je vidljiv'><input type='checkbox' name='brand[visible]' value='1' <?= @$brand['visible'] ? "checked='checked'":"" ?> /> brend je vidljiv</label></td></tr>

      <tr><td colspan=2><hr /><b>SEO:</b> </td></tr>
      <tr><td>Opis: </td><td><textarea name='brand[descr]'><?= @$brand['descr'] ?></textarea></td></tr>
      <tr><td>Ključne reči: </td><td><input type=text name='brand[kwrds]'  value='<?= @$brand['kwrds'] ?>'/></td></tr>
      <tr><td>Adresa (url): </td><td><input type=text name='brand[furl]' value='<?= @$brand['furl'] ?>'/></td></tr>
      <tr><td colspan=2><hr /></td></tr>

      <tr><td colspan=2><textarea name='brand[html]' class='contentEditor' style='width:100%; height:200px'><?= @$brand['html'] ?></textarea></td></tr>

      <tr><td colspan=2><hr /></td></tr>

      <tr><td colspan=2><?php include "edit/assortment.php"; ?></td></tr>

      <tr><td colspan=2><hr /></td></tr>

      <tr><td>Logotip (118x118): </td><td><input type=file name='logo' /></td></tr>
      <tr><td colspan=2>
        <?php if(!empty($brand)) { ?>
          <div style='width:126px; height: 126px; background-color: #F00; border: 1px solid #888'><div style='width:118px; height: 118px; border: 4px solid white;'>
          <?php if(!empty($brand['logo'])) echo "<img src=\"".SURI."image.php/".basename($brand['logo'])."?width=118&height=118&image=".SURI.$brand['logo']."\" />"; ?>
          </div></div>
        <?php } ?>
      </td></tr>


      <tr><td colspan=2><input type=submit value='Potvrdi'/></td></tr>
    </table>
  </form>
</div>