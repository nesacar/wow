<?php
$xTics = count($data);
$xStep = 20;
$yTics = 10;
$yStep = 40;
//$yMax = $yMax;
$yUnit = $yMax/$yTics;
$yScale = $yStep * $yTics / $yMax;

$height = 440;
$width  = $xTics * $xStep + 40;

$x0 = 20;
$xX = $x0 + $xTics*$xStep;
$y0 = 420;
$yY = 20;

$img = imagecreate($width, $height);
$white = imagecolorallocate($img, 255, 255, 255);
$black = imagecolorallocate($img,0,0,0);
//$red   = imagecolorallocate($img,255,0,0);
$blue  = imagecolorallocate($img,0,0,255);
$green = imagecolorallocate($img,0,255,0);

$orange = imagecolorallocate($img,255,165,0);
//$purple = imagecolorallocate($img,147,112,219);


$grid_style = array($black,IMG_COLOR_TRANSPARENT);
imagesetstyle($img,$grid_style);

// horizontalne linije i oznake:
for($i=0; $i<=$yTics; $i++) {
	imageline($img,$x0,$y0-$yStep*$i,$xX,$y0-$yStep*$i,IMG_COLOR_STYLED);
	imagestring($img,1,$x0-17,$y0-$yStep*$i-5,$yUnit*$i,$black);
}


// vertikalne linije:

$yOld = $y0; $yOldU = $y0;
for($i=0; $i<$xTics; $i++){
	if($i%5==0){
		imageline($img,$x0+$xStep*$i,$y0,$x0+$xStep*$i,$yY,IMG_COLOR_STYLED);
		imagestring($img,1,$x0+$xStep*$i-20,$y0+7,date("d.m.y",strtotime($data[$i]['datum'])),$black);
	}

	//$pts  = array($x0+$xStep*$i,$y0,$x0+$xStep*$i,$yOld,$x0+$xStep*($i+1),$y0 - $data[$i]['cnt']*$yScale,$x0+$xStep*($i+1),$y0);
	$ptsU  = array($x0+$xStep*$i,$y0,$x0+$xStep*$i,$yOldU,$x0+$xStep*($i+1),$y0 - $data[$i]['ucnt']*$yScale,$x0+$xStep*($i+1),$y0);
	//imagefilledpolygon($img,$pts,4,$blue);
	imagefilledpolygon($img,$ptsU,4,$green);

	imageline($img,$x0+$xStep*$i,$yOld,$x0+$xStep*($i+1),$y0 - $data[$i]['cnt']*$yScale,$blue);

  //imageline($img,$x0+$xStep*$i,$yOldU,$x0+$xStep*($i+1),$y0 - $data[$i]['ucnt']*$yScale,$green);

	$yOld  = $y0 - $data[$i]['cnt'] * $yScale;
	$yOldU = $y0 - $data[$i]['ucnt'] * $yScale;
	imageline($img,$x0+$xStep*$i,$y0,$x0+$xStep*$i,$y0+2,$black);
}
imageline($img,$xX,$y0,$xX,$yY,IMG_COLOR_STYLED);


for($i=20;$i<40; $i++){
  imagearc($img,20,20,($i+1)*2,($i+1)*2,180,270,$orange);
}


header("Content-type: image/png");
imagepng($img);
imagedestroy($img);
exit;


?>