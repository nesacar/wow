<div id='left'>
<ul id='navlevo'>
  <li><a href='<?= AURI ?>newsletter'><img id="nav_sl" width="16" height="16" src="<?= ATURI ?>images/clanci.png">STATUS</a></li>
  <li><a href='<?= AURI ?>newsletter/new'><img id="nav_sl" width="16" height="16" src="<?= ATURI ?>images/novastrana.png">NOVI MAIL</a></li>
  <li><a href='<?= AURI ?>newsletter/sent'><img id="nav_sl" width="16" height="16" src="<?= ATURI ?>images/clanci.png">POSLATI MAILOVI</a></li>
  <?php if($session->status=='owner') { ?><li><a href='<?= AURI ?>newsletter/subscribers'><img id="nav_sl" width="16" height="16" src="<?= ATURI ?>images/fajlovi.png">PRIMAOCI</a></li><?php } ?>
  <li><a href='<?= AURI ?>newsletter/banners'><img id="nav_sl" width="16" height="16" src="<?= ATURI ?>images/banneri.png">BANERI</a></li>
  <li><a href='<?= AURI ?>nl_retarget'><img id="nav_sl" width="16" height="16" src="<?= ATURI ?>images/banneri.png">RETARGET</a></li>

</ul>


<?php if(!empty($sent)) { ?>
<div style='position: absolute; top: 200px; width: 170px;'>
  <h3>Pregled poruka:</h3>

  <table width=100% cellspacing=1 cellpadding=1>
  <tr bgcolor='#AAAAAA'><th width=24>br.</th><th>datum</th></tr>

  <?php
  $i=0;
  foreach($sent as $s) {
    $trc = ++$i % 2 ? "#CCCCCC":"#DDDDDD";
    echo "<tr bgcolor='$trc'><td>$i</td><td><a href='".SURI."admin/newsletter/sent/{$s['id']}'>".date("d.m.Y H:i",strtotime($s['datum']))."</a><br />{$s['scount']}<span style='float:right;font-size:11px; color: #04f' id='ccs{$s['id']}'><a href='javascript:loadClickCt({$s['id']})'>?</a></td></tr>\n";
  }
  ?>
  </table>
</div>
<script type="text/javascript">
function loadClickCt(nlid){
  $('#ccs'+nlid).html('...');
  $.post("<?= AURI ?>nl_actions",{action:'quickclickct',nlid:nlid},function(data){$('#ccs'+nlid).html(data)});
}
</script>

<?php } ?>

</div>

