<h1>Nova TOP kategorija</h1>
<div class='group' style='width:420px;'>
  <form method=post action="<?= AURI ?>topcat_save">
    <table>
      <tr><td>Nadkategorija:</td>
        <td>
          <select name='tcat[parent]'>
            <option value='0'>Bez nadkategorije (na vrhu)</option>
            <?php foreach($tcatList as $c) echo "<option value='{$c['id']}'>{$c['pos']}. ".(empty($c['title']) ? "bez naslova":$c['title'])."</option>\n" ?>
          </select>
        </td>
      </tr>
      <tr><td>Pozicija u meniju:</td><td><input type=text name='tcat[pos]' required='required' /> <span class='tip'>(0 za skrivenu kategoriju)</span></td></tr>
      <tr><td>Naziv:</td><td><input type=text name='tcat[title]' required='required' /></td></tr>

      <tr><td>Vrsta prikaza:</td>
        <td>
          <select name='tcat[catview]'>
            <?php foreach(@$views as $v) echo "<option value='{$v['id']}'>{$v['title']}</option>\n" ?>
          </select>
        </td>
      </tr>

      <tr><td colspan=2><hr /><b>SEO:</b></td></tr>
      <tr><td>Meta title: </td><td><input type=text name='tcat[meta_title]' /></td></tr>
      <tr><td>Opis:</td><td><textarea name='tcat[descr]'></textarea></td></tr>
      <tr><td>Ključne reči:</td><td><input type=text name='tcat[kwrds]' /></td></tr>
      <tr><td>Adresa (url):</td><td><input type=text name='tcat[furl]' /></td></tr>
      <tr><td colspan=2><hr /></td></tr>
      <tr><td colspan=2><input type=submit value='SNIMI'/></td></tr>
    </table>
  </form>
</div>