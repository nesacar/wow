<?php if(empty($engineList)) return; ?>

<?php if(!empty($engineList['petrol'])) { ?>
  <div class='group' style='width:770px'>
    <b>Benzinski motori:</b>
    <div class='spacer10'></div>
    <table class='tblh' width=770 border="0" cellpadding="0" cellspacing="0">
    <?php
    $i = 0;
    foreach($engineList['petrol'] as $e) {
      $trc = $i++ % 2 ? "nepar":"par";
      if($e['visible']==0) $trc = "invisible";
      echo "<tr class='{$trc}'><td><a href='".AURI."car_engine_edit/{$e['id']}'>{$e['title']}</a></td>"
          ."<td><div class='del'><label title='Obriši'><input type=button value='X' onClick=\"obrisiMotor('{$e['id']}')\"/></label></div></tr>\n";
    }
    ?>
    </table>
  </div>
<?php } ?>

<?php if(!empty($engineList['diesel'])) { ?>
  <div class='group' style='width:770px'>
    <b>Dizel motori:</b>
    <div class='spacer10'></div>
    <table class='tblh' width=770 border="0" cellpadding="0" cellspacing="0">
    <?php
    $i = 0;
    foreach($engineList['diesel'] as $e) {
      $trc = $i++ % 2 ? "nepar":"par";
      if($e['visible']==0) $trc = "invisible";
      echo "<tr class='{$trc}'><td><a href='".AURI."car_engine_edit/{$e['id']}'>{$e['title']}</a></td>"
          ."<td><div class='del'><label title='Obriši'><input type=button value='X' onClick=\"obrisiMotor('{$e['id']}')\"/></label></div></tr>\n";
    }
    ?>
    </table>
  </div>
<?php } ?>

<?php if(!empty($engineList['cng'])) { ?>
  <div class='group' style='width:770px'>
    <b>TNG motori:</b>
    <div class='spacer10'></div>
    <table class='tblh' width=770 border="0" cellpadding="0" cellspacing="0">
    <?php
    $i = 0;
    foreach($engineList['cng'] as $e) {
      $trc = $i++ % 2 ? "nepar":"par";
      if($e['visible']==0) $trc = "invisible";
      echo "<tr class='{$trc}'><td><a href='".AURI."car_engine_edit/{$e['id']}'>{$e['title']}</a></td>"
          ."<td><div class='del'><label title='Obriši'><input type=button value='X' onClick=\"obrisiMotor('{$e['id']}')\"/></label></div></tr>\n";
    }
    ?>
    </table>
  </div>
<?php } ?>

<?php if(!empty($engineList['electric'])) { ?>
  <div class='group' style='width:770px'>
    <b>Električni motori:</b>
    <div class='spacer10'></div>
    <table class='tblh' width=770 border="0" cellpadding="0" cellspacing="0">
    <?php
    $i = 0;
    foreach($engineList['electric'] as $e) {
      $trc = $i++ % 2 ? "nepar":"par";
      if($e['visible']==0) $trc = "invisible";
      echo "<tr class='{$trc}'><td><a href='".AURI."car_engine_edit/{$e['id']}'>{$e['title']}</a></td>"
          ."<td><div class='del'><label title='Obriši'><input type=button value='X' onClick=\"obrisiMotor('{$e['id']}')\"/></label></div></tr>\n";
    }
    ?>
    </table>
  </div>
<?php } ?>

<?php if(!empty($engineList['hybrid'])) { ?>
  <div class='group' style='width:770px'>
    <b>Hibridni motori:</b>
    <div class='spacer10'></div>
    <table class='tblh' width=770 border="0" cellpadding="0" cellspacing="0">
    <?php
    $i = 0;
    foreach($engineList['hybrid'] as $e) {
      $trc = $i++ % 2 ? "nepar":"par";
      if($e['visible']==0) $trc = "invisible";
      echo "<tr class='{$trc}'><td><a href='".AURI."car_engine_edit/{$e['id']}'>{$e['title']}</a></td>"
          ."<td><div class='del'><label title='Obriši'><input type=button value='X' onClick=\"obrisiMotor('{$e['id']}')\"/></label></div></tr>\n";
    }
    ?>
    </table>
  </div>
<?php } ?>