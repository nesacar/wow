<?php if(empty($modelList)) return; ?>

<div style='height: 400px; float:left; position:relative;'>
  <table class='tblh' width=770 border="0" cellpadding="0" cellspacing="0">
  <tr class='listtitle' ><th width=64>GODINA</th><th>NAZIV</th><th width=32>X</th></tr>
  <?php
  $i = 0;
  foreach($modelList as $m) {
    $trc = ++$i % 2 ? "nepar":"par";
    if($m['visible']==0) $trc = "invisible";
    echo "<tr class='{$trc}'><td>{$m['year']}</td><td><a href='".AURI."car_model_edit/{$m['id']}'>{$m['title']}</a></td>"
        ."<td><div class='del'><label title='Obriši'><input type=button value='X' onClick=\"obrisiModel('{$m['id']}')\"/></label></div></tr>\n";
  }
  ?>
  </table>
</div>

