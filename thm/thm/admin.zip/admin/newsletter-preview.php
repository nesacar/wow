<?php
$brs = count($msg_articles);
$brb = count($msg_banners);

$bi = 0;

$mainTitle = $setup->main_title;
$siteUrl   = $setup->site_url;
?>

<style>
.maildiv {font-family: "Trebuchet MS", Georgia, "Times New Roman", Times, serif;font-size:14px;color:#FFF; background-color: #000;}

.mailh1 {font-size:24px; margin: 0px 0px 17px 0px;font-weight:normal;}

.maildiv a:link    {color: #CFBC8C; }
.maildiv a:visited {color: #CFBC8C; }
.maildiv a:hover   {color: #CFBC8C; }
.maildiv a:active  {color: #CFBC8C; }

a.vise:link    {color: #CFBC8C; }
a.vise:visited {color: #CFBC8C; }
a.vise:hover   {color: #CFBC8C; }
a.vise:active  {color: #CFBC8C; }


</style>

<script type="text/javascript">
function brisanje(){
 if(!confirm("Poruka će biti obrisana. Nastavak?")) return;
 window.location.replace("<?= AURI ?>newsletter/cancel/<?= $id_nl ?>");
}
function slanje(){
	if(!confirm("Slanje poruke?")) return;
	window.location.replace("<?= AURI ?>newsletter/send");
}

</script>

<h2>Newsletter</h2>
<hr />
<div class='group'  style='width: 760px'>
<h3><?= $subject ?></h3>
</div>
<div class='group'  style='width: 760px'>

<div class='maildiv' style='padding: 20px 0px 5px 0px;'>
<div align=center>

<table style='width:728px; text-align:left' cellspacing='10' cellpadding='0' border='0'>
<tr><td>
  <a href='<?= SURI ?>'><img src='<?= SURI ?>res/newsletter/header.jpg' border='0' /></a>
</td></tr>

<?php
while($brb && $bi < $brb && $msg_banners[$bi]['after']==0) {
  echo "<tr><td><a href='http://{$msg_banners[$bi]['url']}'><img src='data:{$msg_banners[$bi]['slikaMime']};base64,{$msg_banners[$bi]['slikaEnc64']}' /></a></td></tr> \n";
  $bi++;
}

$a = $msg_articles[0];
$a['slika'] = obradaSlike($a['timg'],418,1,$message['a1cropposition']);
$url = Page::getLink($a);

$tsplit = explode("  ",$a['title']);
$j = 0; $title = "";
foreach($tsplit as $t) $title .= (++$j % 2) ? $t." " : "<span style='color:#FFF;'>{$t}</span> ";

$title = "<h1 class='mailh1'><a href='$url'>{$title}</a></h1>";
$body = $a['descr'];


echo "<tr><td style='border-bottom: 1px solid #666'><table style='width:728px;' cellspacing='0' cellpadding='0' border='0'>";
echo "<tr><td style='width:428px'><a href='{$url}'><img style='float:left;' src='data:{$a['slika']['slikaMime']};base64,{$a['slika']['slikaEnc64']}'/></a></td> \n";
echo "<td><a href='http://{$msg_banner300['url']}'><img src='data:{$msg_banner300['slikaMime']};base64,{$msg_banner300['slikaEnc64']}' border='0' /></a></td></tr>";
echo "<tr><td colspan='2' style='padding:10px;'>{$title} {$body} <br /><a class='vise' href='{$url}'>» <span style='color:#999'>Pročitajte&nbsp;više</span>...</a></td></tr> \n";
echo "</table></td></tr>\n";


for($i = 1; $i < $brs; $i++){
  while($brb && $bi < $brb && $msg_banners[$bi]['after']==$i) {
    echo "<tr><td><a href='http://{$msg_banners[$bi]['url']}'><img src='data:{$msg_banners[$bi]['slikaMime']};base64,{$msg_banners[$bi]['slikaEnc64']}' /></a></td></tr> \n";
    $bi++;
  }
  $a = $msg_articles[$i];
  $a['slika'] = obradaSlike($a['timg']);

  $url = Page::getLink($a);

  $tsplit = explode("  ",$a['title']);
  $j = 0; $title = "";
  foreach($tsplit as $t) $title .= (++$j % 2) ? $t." " : "<span style='color:#FFF;'>{$t}</span> ";

  $title = "<h1 class='mailh1'><a href='$url'>{$title}</a></h1>";
  $body = $a['descr'];

  echo "<tr><td style='border-bottom: 1px solid #666; padding-bottom: 5px;'><table style='width:728px;' cellspacing='0' cellpadding='0' border='0'>";
  echo "<tr><td><a href='{$url}'><img src='data:{$a['slika']['slikaMime']};base64,{$a['slika']['slikaEnc64']}'/></a></td> \n";
  echo "<td style='padding:10px; width: 481px; height:119px; overflow:hidden'>{$title} {$body}<br /><a class='vise' href='{$url}'>» <span style='color:#999'>Pročitajte&nbsp;više</span>...</a> </td></tr> \n";
  echo "</table></td></tr>\n";

}
while($brb && $bi<$brb){
  echo "<tr><td><a href='http://{$msg_banners[$bi]['url']}'><img src='data:{$msg_banners[$bi]['slikaMime']};base64,{$msg_banners[$bi]['slikaEnc64']}' /></a></td></tr>\n";
  $bi++;
}




?>
<tr><td>
<table style='width:728px;' cellspacing='0' cellpadding='0' border='0'>
  <tr><td style='width:540px'><img src='<?= SURI ?>res/newsletter/footer.gif' alt='footer'></td>
  <td style='width:171px;'><a href='<?= $setup->link_fb ?>'><img src='<?= SURI ?>res/newsletter/nl-fb.gif'/></a><a href='<?= $setup->link_twt ?>'><img src='<?= SURI ?>res/newsletter/nl-twt.gif'/></a><a href='<?= SURI ?>rss'><img src='<?= SURI ?>res/newsletter/nl-rss.gif'/></a></td>
  <td style='width:17px'><img src='<?= SURI ?>res/newsletter/footer-end.gif' alt='footer'></td></tr>
</table>
</td></tr>
<tr><td style='font-size:18px;padding:10px'>
  Da biste se odjavili sa mejling liste sitea <?= $mainTitle ?>, kliknite ovdje: <br />
  <a class='vise' href='#'><?= SURI ?>newsletter/odjava/...</a><br />

</td></tr>
</table>

</div>
</div>
</div>


<div class='group'  style='width: 760px'>
<div align=center>
  <input type=button value='Pošalji' onClick="slanje()" />
  <input type=button value='Otkaži' onClick="brisanje()"/>
</div>
</div>

<?php
function obradaSlike($img,$w=218,$crop=false,$croppos='center'){
  $url = SURI.'image.php';
  $get = 'image='.urlencode(SURI.$img).'&width='.(int)$w;
  if($crop) $get .= "&cropratio=418:250&cropposition=".urlencode($croppos);
  $url .= "?".$get;

  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $url);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_HEADER, 0);
  $response = curl_exec($ch);

  $ret = array('slikaEnc64'=>base64_encode($response),'slikaMime'=>curl_getinfo($ch,CURLINFO_CONTENT_TYPE));
  curl_close($ch);

  return $ret;
}

?>
