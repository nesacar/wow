<?php
$mainTitle = $setup->main_title;
$siteUrl   = $setup->site_url;
?>
<h2>Newsletter</h2>
<hr />


<?php if(!empty($message)) { ?>
<style>
.maildiv {font-family: Arial;font-size:14px;color:#FFF; background-color: #000;}

.mailh1 {font-size: 24px; margin: 0px 0px 17px 0px;font-weight:normal;}

.maildiv a:link    {color: #CFBC8C; }
.maildiv a:visited {color: #CFBC8C; }
.maildiv a:hover   {color: #CFBC8C; }
.maildiv a:active  {color: #CFBC8C; }

a.vise:link    {color: #CFBC8C; }
a.vise:visited {color: #CFBC8C; }
a.vise:hover   {color: #CFBC8C; }
a.vise:active  {color: #CFBC8C; }
</style>

<div class='group' style='width: 760px'>
<p><?= date('d.m.Y H:i',strtotime($message['datum'])) ?></p>
<h3><?= empty($message['subject']) ? $setup->main_title : $message['subject'] ?></h3>
<p>Poslato na <?= $message['scount'] ?> adresa</p>
</div>
<div class='group' style='width: 760px'>

<div class='maildiv' padding: 20px 0px 5px 0px;'>
  <div align=center>
    <div style='width:728px; text-align:left'>
      <a href='<?= SURI ?>'><img src='<?= SURI ?>res/newsletter/header.jpg' border=0 /></a>
      <div style='height:10px; clear:both'></div>
<?php

$brs = count($message['articles']);
$brb = count($message['banners']);
$msg_articles = $message['articles'];
$msg_banners  = $message['banners'];
$msg_banner300= $message['banner300'];

$bi = 0;
$bnrclk = 0; $artclk = 0;
while($brb && $bi < $brb && $msg_banners[$bi]['after']==0) {
  echo "<a href='http://{$msg_banners[$bi]['url']}'><img src='data:{$msg_banners[$bi]['slikaMime']};base64,{$msg_banners[$bi]['slikaEnc64']}' /></a> \n";
  echo "<div style='position:relative;left:5px;top:-80px;width:120px;height:20px;background-color:#FFF;color:#000;padding-left:8px'>Klikova: {$msg_banners[$bi]['cnt']}</div>";
  echo "<div style='margin-top:-20px;height:10px; clear:both'></div>\n";
  $bnrclk += $msg_banners[$bi]['cnt'];
  $bi++;
}

$a = $msg_articles[0];
$a['slika'] = obradaSlike($a['timg'],418,true,$message['a1cropposition']);

$url = Page::getLink($a);

$tsplit = explode("  ",$a['title']);
$j = 0; $title = "";
foreach($tsplit as $t) $title .= (++$j % 2) ? $t." " : "<span style='color:#FFF;'>{$t}</span> ";

$title = "<h1 class='mailh1'><a href='$url'>{$title}</a></h1>";
$body = $a['descr'];


echo "<a href='{$url}'><img style='float:left;' src='data:{$a['slika']['slikaMime']};base64,{$a['slika']['slikaEnc64']}'/></a> \n";
echo "<a href='http://{$msg_banner300['url']}'><img style='margin-left:10px' src='data:{$msg_banner300['slikaMime']};base64,{$msg_banner300['slikaEnc64']}' /></a>\n";
echo "<div style='position:relative;left:5px;top:-240px;width:120px;height:20px;background-color:#FFF;color:#000;padding-left:8px'>Klikova: {$a['cnt']}</div>";
echo "<div style='position:relative;left:440px;top:-260px;width:120px;height:20px;background-color:#FFF;color:#000;padding-left:8px'>Klikova: {$msg_banner300['cnt']}</div>";
echo "<div style='margin-top:-40px;margin-left:10px;padding:10px;'>{$title} {$body} <br />» <a href='{$url}' class='vise'>Pročitajte&nbsp;više...</a> </div> \n";
echo "<div style='height:10px; clear:both'></div>\n";
$artclk += $a['cnt'];
$bnrclk += $msg_banner300['cnt'];

for($i = 1; $i < $brs; $i++){
  while($brb && $bi < $brb && $msg_banners[$bi]['after']==$i) {
    echo "<a href='http://{$msg_banners[$bi]['url']}'><img src='data:{$msg_banners[$bi]['slikaMime']};base64,{$msg_banners[$bi]['slikaEnc64']}' /></a> \n";
    echo "<div style='position:relative;left:5px;top:-80px;width:120px;height:20px;background-color:#FFF;color:#000;padding-left:8px'>Klikova: {$msg_banners[$bi]['cnt']}</div>";
    echo "<div style='margin-top:-20px;height:10px; clear:both'></div>\n";
    $bnrclk += $msg_banners[$bi]['cnt'];
    $bi++;
  }

  $a = $msg_articles[$i];
  $a['slika'] = obradaSlike($a['timg']);

  $url = Page::getLink($a);

  $tsplit = explode("  ",$a['title']);
  $j = 0; $title = "";
  foreach($tsplit as $t) $title .= (++$j % 2) ? $t." " : "<span style='color:#FFF;'>{$t}</span> ";

  $title = "<h1 class='mailh1'><a href='$url'>{$title}</a></h1>";
  $body = $a['descr'];

  echo "<a href='{$url}'><img style='float:left;' src='data:{$a['slika']['slikaMime']};base64,{$a['slika']['slikaEnc64']}'/></a> \n";
  echo "<div style='float:right;padding:10px; width: 470px; height:119px; overflow:hidden'>{$title} {$body}<br />» <a href='{$url}' class='vise'>Pročitajte&nbsp;više...</a> </div> \n";
  echo "<div style='height:10px; clear:both'></div>\n";
  echo "<div style='position:relative;left:5px;top:-149px;width:120px;height:20px;background-color:#FFF;color:#000;padding-left:8px'>Klikova: {$a['cnt']}</div>";
  $artclk += $a['cnt'];

}
while($brb && $bi<$brb){
  echo "<a href='http://{$msg_banners[$bi]['url']}'><img src='data:{$msg_banners[$bi]['slikaMime']};base64,{$msg_banners[$bi]['slikaEnc64']}' /></a> \n";
  echo "<div style='height:10px; clear:both'></div>\n";
  echo "<div style='position:relative;left:5px;top:-95px;width:120px;height:20px;background-color:#FFF;color:#000;padding-left:8px'>Klikova: {$msg_banners[$bi]['cnt']}</div>";
  $bnrclk += $msg_banners[$bi]['cnt'];
  $bi++;
}

?>
      <div style='height:10px; clear:both'></div>
      <div style='height:84px;width:728px;'>
        <div style='float:left;width:540px'><img src='<?= SURI ?>res/newsletter/footer.gif' alt='footer'></div>
        <div style='width:171px;float:left'><a href='<?= $setup->link_fb ?>'><img src='<?= SURI ?>res/newsletter/nl-fb.gif'/></a><a href='<?= $setup->link_twt ?>'><img src='<?= SURI ?>res/newsletter/nl-twt.gif'/></a><a href='<?= SURI ?>rss'><img src='<?= SURI ?>res/newsletter/nl-rss.gif'/></a></div>
        <div style='width:17px;float:left'><img src='<?= SURI ?>res/newsletter/footer-end.gif' alt='footer'></div>
      </div>
      <div style='height:5px; clear:both'></div>
      <div style='font-size:18px;padding:0px'>
        Da biste se odjavili sa mejling liste sitea <?= $mainTitle ?>, kliknite ovdje: <br />
        <a class='vise' href='#'><?= SURI ?>newsletter/odjava/...</a><br />

      </div>
    </div>
  </div>
</div>


</div>
<div class='group'>
<h3>Zbir klikova</h3>
Baneri: <?= $bnrclk ?> <br />
Članci: <?= $artclk ?>
</div>

<div class='group'>
<h3>Send again</h3>
  <form method="post" action="<?= AURI ?>nl_actions" onSubmit="return confirm('Are you sure you want to send this message again?')">
    <input type='hidden' name='action' value='resend' />
    <input type='hidden' name='nlid' value='<?= $message['id'] ?>' />
    <input type='submit' value='Send again' />
  </form>
</div>

<?php } ?>




<?php
function obradaSlike($img,$w=218,$crop=false,$croppos='center'){
  $url = SURI.'image.php';
  $get = 'image='.urlencode(SURI.$img).'&width='.(int)$w;
  if($crop) $get .= "&cropratio=418:250&cropposition=".urlencode($croppos);
  $url .= "?".$get;

  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, $url);
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_HEADER, 0);
  $response = curl_exec($ch);

  $ret = array('slikaEnc64'=>base64_encode($response),'slikaMime'=>curl_getinfo($ch,CURLINFO_CONTENT_TYPE));
  curl_close($ch);

  return $ret;
}
?>