<h1>GDK UREĐIVANJE KATEGORIJA PROIZVODA</h1>
<div class='infobox'>
<p>Na ovoj stranici možete uređivati kategorije GDK menija.</p>
<p>Ukoliko je status kategorije "0" neće se prikazivati u meniju.</p>
</div>

<div class='group'><b><a href='<?= AURI ?>gdk_cat_edit'>» Dodaj novu kategoriju</a></b></div>

<?php foreach($catList as $c){ ?>
  <div class='group'>
    <div class='top'>
      <?= $c['pos'] ?>.
      <a href='<?= AURI ?>gdk_cat_edit/<?= $c['id'] ?>'><?= empty($c['title']) ? "bez naslova":$c['title'] ?></a>
      <div class='del'>
        <label title='Obriši'>
          <input type=button value='X' onClick="obrisi('<?= $c['id'] ?>')"/>
        </label>
      </div>
    </div>

    <?php if(!empty($c['sub'])) foreach($c['sub'] as $s) { ?>
      <div class='sub'>
        <div class='top'>
          <?= $s['pos'] ?>.
          <a href='<?= AURI ?>gdk_cat_edit/<?= $s['id'] ?>'><?= empty($s['title']) ? "untitled":$s['title'] ?> <?= true || empty($s['title_eng']) ? "" : "<span style='font-size:11px'>({$s['title_eng']})</span>" ?></a>
          <div class='del'>
            <label title='Obriši'>
              <input type=button value='X' onClick="obrisi('<?= $s['id'] ?>')"/>
            </label>
          </div>
          <input type='text' style='float: right; width: 72px; text-align: center; margin-right: 10px' onFocus="select()" onClick="select()" value="<?= $s['id'] ?>" readonly />
        </div>
      </div>
    <?php } ?>

    <div class='spacer0'></div>
  </div>
<?php } ?>


<script type="text/javascript">
function obrisi(id) {
  if(!confirm('Brisanje kategorije?')) return false;
  $.post("<?= AURI ?>gdk_cat_del", {id:id}, function(data){window.location.reload()});
}
</script>