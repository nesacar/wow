<h1><?= empty($assortment) ? "Nova kategorija asortimana" : "Izmena kategorije asortimana: " . $assortment['title'] ?>"</h1>
<div class='group' style='width:420px;'>
  <form method=post enctype='multipart/form-data' action="<?= AURI ?>gdk_assortment_save">
    <input type=hidden name='assortment[id]' value='<?= @$assortment['id'] ?>' />
    <table>
      <tr><td>Nadkategorija:</td>
        <td>
          <select name='assortment[parent]'>
            <option value='0'>Bez nadkategorije (na vrhu)</option>
            <?php foreach($assortmentList as $a) if($assortment['id']!=$a['id']) echo "<option value='{$a['id']}' ".($assortment['parent']==$a['id'] ? "selected='selected'":"").">{$a['pos']}. ".(empty($a['title']) ? "bez naslova":$a['title'])."</option>\n" ?>
          </select>
        </td>
      </tr>
      <tr><td>Pozicija u meniju:</td><td><input type=text name='assortment[pos]' value='<?= @$assortment['pos'] ?>' required='required' /></td></tr>
      <tr><td>Naziv:</td><td><input type=text name='assortment[title]' value='<?= @$assortment['title'] ?>' required='required' /></td></tr>

      <tr><td>Ikona (40x40): </td><td><input type=file name='img' /></td></tr>
      <tr><td colspan=2>
        <?php if(!empty($assortment['img'])) { ?>
          <div style='width:48px; height: 48px; background-color: #F00; border: 1px solid #888'><div style='width:40px; height: 40px; border: 4px solid white;'>
            <img src="<?= SURI . $assortment['img'] ?>" style="width:40px; height: 40px;" />
          </div></div>
        <?php } ?>
      </td></tr>

      <tr><td colspan=2><input type=submit value='Potvrdi'/></td></tr>
    </table>
  </form>
</div>