<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.8.18/jquery-ui.min.js" type="text/javascript"></script>
<link rel="stylesheet" href="<?= ATURI ?>css/humanity/jquery-ui-1.8.18.custom.css">
<script type="text/javascript">
$(document).ready(function() {
  $(".datum").datepicker({dateFormat:'yy-mm-dd',firstDay:1,changeMonth:true,changeYear:true,onSelect:setFilter,
    dayNamesMin:['N','P','U','S','Č','P','S'],
    monthNamesShort:['Jan','Feb','Mar','Apr','Maj','Jun','Jul','Avg','Sep','Okt','Nov','Dec']
    });
});
</script>

<h1>GDK STATISTIKA PRIKAZA</h1>

<div class='group' style='width:757px;'>
  <form onSubmit="return false" id="gsf_form">
    Brand:
    <select name='brand' id='gsf_brand' onChange="setFilter()" style='width: 90px'>
      <option value='0'>Svi brendovi</option>
      <?php
        foreach($brandList as $b) {
          echo "<option value='{$b['id']}' ".($b['id']==@$_SESSION['gsf_brand'] ? "selected='selected'":"").">".(empty($b['title']) ? "bez naziva":$b['title'])."</option>\n";
        }
      ?>
    </select>

    Distributer:
    <select name='dist' id='gsf_dist' onChange="setFilter()" style='width: 90px'>
      <option value='0'>Svi distributeri</option>
      <?php
        foreach($distList as $d) {
          echo "<option value='{$d['id']}' ".($d['id']==@$_SESSION['gsf_dist'] ? "selected='selected'":"").">".(empty($d['title']) ? "bez naziva":$d['title'])."</option>\n";
        }
      ?>
    </select>

    Kategorija:
    <select name='cat' id='gsf_cat' onChange="setFilter()" style='width: 90px'>
      <option value='0'>Sve kategorije</option>
      <?php
        foreach($catList as $c) {
          echo "<option value='{$c['id']}' ".($c['id']==@$_SESSION['gsf_cat'] ? "selected='selected'":"").">{$c['pos']}. ".(empty($c['title']) ? "bez naslova":$c['title'])."</option>\n";
          if(!empty($c['sub'])) foreach ($c['sub'] as $s)
          echo "<option value='{$s['id']}' ".($s['id']==@$_SESSION['gsf_cat'] ? "selected='selected'":"").">-- {$c['pos']}.{$s['pos']}. ".(empty($s['title']) ? "bez naslova":$s['title'])."</option>\n";
        }
      ?>
    </select>


    od <input type=text name='d1' id='gsf_d1' value='<?= @$_SESSION['gsf_d1'] ?>' class='datum' style='width: 66px'/>
    do <input type=text name='d2' id='gsf_d2' value='<?= @$_SESSION['gsf_d2'] ?>' class='datum' style='width: 66px'/>
    <input type=button value='X' onClick="resetFilter()" />
  </form>

</div>

<div id='product_filtered_list' style='clear:both'>
<?php include "gdk-stats-list.php"; ?>
</div>

<script type="text/javascript">
function setFilter(){
  $.post("<?= AURI ?>gdk_stats_list",$("#gsf_form").serialize(),function(data){$("#product_filtered_list").html(data)});
}
function resetFilter(){
  $("#gsf_cat").val(''); $("#gsf_dist").val(''); $("#gsf_brand").val('');
  $("#gsf_d1").val('');$("#gsf_d2").val('');
  setFilter();
}
</script>