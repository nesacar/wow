<?php if(empty($seriesList)) return; ?>

<div style='height: 400px; float:left; position:relative;'>
  <table class='tblh' width=770 border="0" cellpadding="0" cellspacing="0">
  <tr class='listtitle' ><th width=64>GODINA</th><th>NAZIV</th><th width=32>X</th></tr>
  <?php
  $i = 0;
  foreach($seriesList as $s) {
    $trc = ++$i % 2 ? "nepar":"par";
    if($s['discontinued']==1) $trc = "discontinued";
    if($s['visible']==0) $trc = "invisible";
    echo "<tr class='{$trc}'><td>{$s['year']}</td><td><a href='".AURI."car_series_edit/{$s['id']}'>{$s['title']}</a></td>"
        ."<td><div class='del'><label title='Obriši'><input type=button value='X' onClick=\"obrisiSeriju('{$s['id']}')\"/></label></div></tr>\n";
  }
  ?>
  </table>
</div>

