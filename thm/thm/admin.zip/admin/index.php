<!DOCTYPE HTML>
<html>
<head>
  <meta charset="UTF-8" />
  <title><?php echo isset($page['title']) ? $page['title'] . ' | ' : '' ?><?= $setup->main_title ?> - Admin</title>
  <meta name="author" content="Web Operater [http://weboperater.com]" />
  <link rel="shortcut icon" href="<?= SURI ?>favicon.ico" type="image/x-icon" />
  <link rel="stylesheet" type="text/css" href="<?= ATURI ?>css/admin.css" />
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js" type="text/javascript"></script>
  <!--[if lte IE 8]>
    <style>
      #nav { left: 0}
    </style>
  <![endif]-->
</head>
<body>
	<div id='wrapper'>


		<? include 'menu.php'; ?>

		<? if(!empty($left)) include $left; ?>
    	<div id='center'><? include $body; ?></div>

	</div>
</div>
</div>
</body>
</html>