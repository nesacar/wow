<h1>Lista motora</h1>
<div class='group' style='width:757px;'>
  Brend:
  <select id='brand_select' onChange="selectBrand(this.value)">
    <option value='-1'>Odaberite brend</option>
    <option value='0'>Serije bez brenda</option>
    <?php foreach($brandList as $b) echo "<option value='{$b['id']}'>{$b['title']}</option>\n"; ?>
  </select>

  <select id='series_select' onChange="selectSeries(this.value)">
    <option value='-1'>Odaberite seriju</option>
    <option value='0'>Modeli bez serije</option>
  </select>

  <select id='model_select' onChange="selectModel(this.value)">
    <option value='-1'>Odaberite model</option>
    <option value='0'>Motori bez modela</option>
  </select>

</div>

<div id='engine_list'>
  <?php include "cars-engines-list.php"; ?>
</div>

<script type="text/javascript">
function obrisiMotor(id) {
  if(!confirm('Brisanje motora?')) return false;
  $.post("<?= AURI ?>car_engine_del", {eid:id}, function(data){selectModel($('#model_select').val())});
}
</script>

<script type="text/javascript">
function selectBrand(bid){
  $('#series_select option:gt(1)').remove();
  $('#series_select').val(-1);
  $('#model_select option:gt(1)').remove();
  $('#model_select').val(-1);
  $.post("<?= SURI ?>fillSelector",{selector:'series',parent:bid,includeDisabled:true},function(data){$('#series_select').append(data)});
}

function selectSeries(sid){
  $('#model_select option:gt(1)').remove();
  $('#model_select').val(-1);
  $.post("<?= SURI ?>fillSelector",{selector:'model',parent:sid,includeDisabled:true},function(data){$('#model_select').append(data)});
}
function selectModel(mid){
  $.post("<?= AURI ?>/car_engines_list",{model:mid},function(data){$("#engine_list").html(data)});
}
</script>