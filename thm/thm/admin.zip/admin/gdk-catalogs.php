<h1>GDK UREĐIVANJE KATALOGA DISTRIBUTERA</h1>

<div class='group'><b><a href='<?= AURI ?>gdk_catalog_edit'>» Dodaj novi katalog</a></b></div>

<?php foreach($distList as $d) if(!empty($d['catalogs'])) { ?>
  <div class='group'>
    <div class='top'>
      <a href='<?= AURI ?>gdk_dist_view/<?= $d['id'] ?>'><?= empty($d['title']) ? "bez naziva":$d['title'] ?></a>
    </div>

    <?php foreach($d['catalogs'] as $c) { ?>
      <div class='sub'>
        <div class='top'>
          <a href='<?= AURI ?>gdk_catalog_edit/<?= $c['id'] ?>'><?= empty($c['title']) ? "bez naziva":$c['title'] ?></a>
          <div class='del'>
            <label title='Obriši'>
              <input type=button value='X' onClick="obrisi('<?= $c['id'] ?>')"/>
            </label>
          </div>
        </div>
      </div>
    <?php } ?>

    <div class='spacer0'></div>
  </div>
<?php } ?>


<script type="text/javascript">
function obrisi(id) {
  if(!confirm('Brisanje kataloga?')) return false;
  $.post("<?= AURI ?>gdk_catalog_del", {id:id}, function(data){window.location.reload()});
}
</script>