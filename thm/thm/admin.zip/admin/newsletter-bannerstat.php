<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.8.18/jquery-ui.min.js" type="text/javascript"></script>
<link rel="stylesheet" href="<?= ATURI ?>css/humanity/jquery-ui-1.8.18.custom.css">
<script type="text/javascript">
$(document).ready(function() {
  $(".datum").datepicker({dateFormat:'yy-mm-dd',firstDay:1,changeMonth:true,changeYear:true,
    dayNamesMin:['N','P','U','S','Č','P','S'],
    monthNamesShort:['Jan','Feb','Mar','Apr','Maj','Jun','Jul','Avg','Sep','Okt','Nov','Dec']
    });

});
</script>

<h2>Newsletter banner stats</h2>
<hr />

<div class='group' style='width: 760px'>
  <h3>Banner: <?= 'http://'.$b['url'] ?></h3>
  <img src='data:<?= $b['slikaMime'] ?>;base64,<?= $b['slikaEnc64'] ?>' />
<hr />
 <form method=post >
   <b>Prikaži statistiku</b><br />
   od: <input type=text class='datum' name='d1' value='<?= $d['d1'] ?>'/> &nbsp;
   do: <input type=text class='datum' name='d2' value='<?= $d['d2'] ?>' /> &nbsp;
   <input type=submit value='Prikaži' />

 </form>
</div>

<div class='group' style='width: 760px'>
  <h3>Statistika za period: <?= date("d.m.Y",strtotime($d['d1']))." - ".date("d.m.Y",strtotime($d['d2'])) ?></h3>
  <img src='<?= AURI."newsletter/bannerstatimg/{$b['id']}/{$d['d1']}/{$d['d2']}" ?>' />
  <hr />
   <b>Ukupno klikova: </b><?= (int)$cnt['cnt'] ?>
  &nbsp; &nbsp; &nbsp; | &nbsp; &nbsp; &nbsp;
  <b>Unikatnih klikova: </b><?= (int)$cnt['ucnt'] ?>
  &nbsp; &nbsp; &nbsp; | &nbsp; &nbsp; &nbsp;
  <b>Pojedinačni klikovi: </b><a href="javascript:pClick()">prikaži/sakrij</a>
  <hr />

  <div id='pclk' style='display:none'>

    <table style='margin-top:10px'><tr bgcolor='#AAAAAA'><th colspan=2>Klikovi na banner:</th></tr>
      <?php
       $i=0;
      	foreach($b['usrclk'] AS $bs){
      		$trc = ++$i % 2 ? "#CCCCCC":"#DDDDDD";
        	echo "<tr bgcolor='$trc'><td>{$bs['email']}</td><td align=right width=42>{$bs['cnt']}</td></tr>";
        }
      ?>
      <tr bgcolor='#AAAAAA'><td align=right>Ukupno:</td><td align=right><?= $cnt['cnt'] ?></td></table>
    </table>
  </div>
</div>

<script type="text/javascript">
function pClick(){
	$('#pclk').toggle()
}
</script>

