<h1>Komentari na članak: <?= $p['title'] ?></h1>

<div style='height: 400px; float:left; position:relative;'>
<table class='tblh' width=770 border="0" cellpadding="0" cellspacing="0">
<tr class='listtitle' ><th width=64>DATUM</th><th>AUTOR</th><th>NASLOV</th><th>KOMENTAR</th><th>STATUS</th></tr>
<?php

$stn = array('pending'=>'na čekanju','approved'=>'odobren','rejected'=>'odbijen');

$i = 0;
foreach($comments as $c) {
  $trc = ++$i % 2 ? "nepar":"par";
  if($c['status']=='rejected') $trc = "invisible";
  @print "<tr class='{$trc}'><td valign=top>".nl2br(date("d.m.Y\nH:i",strtotime($c['posted'])))."</td>"
      ."<td valign=top>{$c['author']}</td><td valign=top>{$c['subject']}</td>"
      ."<td valign=top>".nl2br($c['body'])."</td>"
      ."<td valign=top>{$stn[$c['status']]} ".statusButtons($c)."</td>\n";
}
?>
</table>
<script type="text/javascript">
function c_set_status(cid,status){
  $.post("<?= AURI ?>comment_status",{cid:cid,status:status},function(data){window.location.reload()});
}
</script>

<?php
function statusButtons($c){
  if($c['status']!='pending') return "";
  $ret = "
  	<input type=button title='odobri' value='odobri' onClick=\"c_set_status('{$c['id']}',1)\" />
  	<input type=button title='odbij'  value='odbij'  onClick=\"c_set_status('{$c['id']}',0)\" />
  ";
  return $ret;
}
?>