<script type="text/javascript" src="<?= ATURI ?>js/tiny_mce/tiny_mce.js"></script >
<script type="text/javascript" src="<?= ATURI ?>js/tinymce-init.js"></script >

<h1>GDK podešavanja:</h1>
<div class='group' style='width: 760px'>
  <form method='post' action="<?= AURI ?>gdk_settings_save">
    <p>GDK naslov</p>
    <input name='setup[gdk_title]' type=text value='<?= @$setup->gdk_title ?>' maxlength="70"  style='width:400px' />

    <p>&nbsp;</p>
    <p>GDK opis</p>
    <textarea rows='3' name='setup[gdk_descr]' style='width:400px'><?= @$setup->gdk_descr ?></textarea>

    <p>&nbsp;</p>
    <p>GDK ključne reči od 5 do max 10, odvojene [, ]:</p>
    <input type=text name='setup[gdk_kwrds]' value='<?= @$setup->gdk_kwrds ?>'  style='width:400px' />
    <p class='primer'>Primer: tekst, tekst, test, tekst</p>

    <p>&nbsp;</p>
    <p>Footer:</p>
    <textarea rows='4' name='setup[gdk_footer]' class='contentEditor'><?= @$setup->gdk_footer ?></textarea>

    <p>&nbsp;</p>
    <p>&euro; kurs</p>
    <input name='setup[euro_kurs]' type=text value='<?= @$setup->euro_kurs ?>' style='width:400px' />


    <br />
    <input type=submit value='SNIMI'/>
  </form>
</div>