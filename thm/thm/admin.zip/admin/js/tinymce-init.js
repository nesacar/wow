tinyMCE.init({
  mode : "specific_textareas",
  editor_selector : "contentEditor",
  theme : "advanced",

  relative_urls : false,
  remove_script_host : false,
//  document_base_url : "<?= SURI ?>", // DA VIDIMO DA LI CE DA RADI...

  file_browser_callback: "filebrowser",


  plugins : "autolink,lists,advhr,advimage,advlink,inlinepopups,preview,media,searchreplace,contextmenu,paste,table,fullscreen,visualchars",

  // Theme options
  theme_advanced_buttons1 : "fullscreen,code,preview,cleanup,|,cut,copy,paste,pastetext,pasteword,|,undo,redo,|,search,replace,|,removeformat,visualchars,visualaid,|,help",
  theme_advanced_buttons2 : "formatselect,fontsizeselect,|,justifyleft,justifycenter,justifyright,justifyfull,|,bold,italic,underline,|,strikethrough,forecolor,backcolor,|,bullist,numlist,|,outdent,indent",
  theme_advanced_buttons3 : "link,unlink,anchor,|,sub,sup,charmap,|,hr,advhr,|,tablecontrols,|,image,media",
  theme_advanced_toolbar_location : "top",
  theme_advanced_toolbar_align : "left",
  theme_advanced_statusbar_location : "bottom",
//  theme_advanced_resizing : true,

  // Skin options
  skin : "o2k7",
  skin_variant: "silver",

  // Drop lists for link/image/media/template dialogs
//  template_external_list_url : "js/template_list.js",
//  external_link_list_url : "js/link_list.js",
//  external_image_list_url : "js/image_list.js",
//  media_external_list_url : "js/media_list.js",

});
function filebrowser(field_name, url, type, win) {
  fileBrowserURL = "/affix/pdw/?filter=" + type;
  tinyMCE.activeEditor.windowManager.open({
    title: "PDW File Browser",
    url: fileBrowserURL,
    width: 950,
    height: 650,
    inline: 1,
    maximizable: 1,
    close_previous: 0
  },{
    window : win,
    input : field_name
  });
}
