<script type="text/javascript" src="<?= ATURI ?>js/tiny_mce/tiny_mce.js"></script >
<script type="text/javascript" src="<?= ATURI ?>js/tinymce-init.js"></script >

<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.8.18/jquery-ui.min.js" type="text/javascript"></script>
<link rel="stylesheet" href="<?= ATURI ?>css/humanity/jquery-ui-1.8.18.custom.css">
<script type="text/javascript">
$(document).ready(function() {
  $(".datum").datepicker({dateFormat:'yy-mm-dd',firstDay:1,changeMonth:true,changeYear:true,
    dayNamesMin:['N','P','U','S','Č','P','S'],
    monthNamesShort:['Jan','Feb','Mar','Apr','Maj','Jun','Jul','Avg','Sep','Okt','Nov','Dec']
    });

});
</script>

<script type="text/javascript" src="<?= ATURI ?>js/facebox.js"></script>
<link rel="stylesheet" href="<?= ATURI ?>css/facebox.css">
<script type="text/javascript">
jQuery(document).ready(function($) {
  $('a[rel*=facebox]').facebox({
    loadingImage : '<?= ATURI ?>/images/facebox/loading.gif',
    closeImage   : '<?= ATURI ?>/images/facebox/closelabel.png'
  })
})
</script>

<h1>Članak: <?= $page['title'] ?></h1>

<form method='post' enctype='multipart/form-data' action='<?= AURI ?>page_save'>
  <input type=hidden name='page[id]' value='<?= $page['id'] ?>' />
  <input type=hidden name='page[pgt]' value='<?= $page['pgt'] ?>' />
  <table style='float:left; width: 770px;'>
    <?php include 'edit/base.php'; ?>
    <?php include 'edit/seo.php'; ?>
  </table>

  <?php include 'edit/buttonset.php'; ?>

  <?php include 'edit/timg.php'; ?>

  <?php include 'edit/gdk-pagelinks.php'; ?>

  <div class='spacer10'></div>

  <h2>GALERIJA:</h2>
  <a class="galleryprivju" href="<?= AURI ?>gallery_edit/<?= $page['id'] ?>" rel='facebox'>Pregledaj/izmeni galeriju</a>
  <br /><br />

  <textarea name='page[html]' class='contentEditor' style='width:100%; height:400px'><?= $page['contents']['html'] ?></textarea>

  <?php include 'edit/buttonset.php'; ?>
</form>