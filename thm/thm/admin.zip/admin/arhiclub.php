<h1>Arhi Club</h1>
[<b><a href="<?= AURI ?>arhiclub_settings">podešavanja</a></b>]
<hr />

<div class='group'>
  <form onSubmit="return false" id="acf_form">
<input type=text name='search' id='acf_search' onKeyUp="setFilter()" value='<?= @$_SESSION['acf_search'] ?>' placeholder="Pretraga..."  onfocus="blank(this)" onblur="unblank(this)"/>
    <input type=button value='Reset' onClick="resetFilter()" />
  </form>

</div>

<div id='arhiclub_filtered_list'>
<?php include "arhiclub-list.php"; ?>
</div>

<script type="text/javascript">
function setFilter(){
  $.post("<?= AURI ?>/arhiclub_list",$("#acf_form").serialize(),function(data){$("#arhiclub_filtered_list").html(data)});
}
function resetFilter(){
  $("#acf_search").val('');
  setFilter();
}
function setPage(p){
  if(p==0) p = $('#jump_to_page').val();
  $.post("<?= AURI ?>/arhiclub_list",{page_num:p},function(data){$("#arhiclub_filtered_list").html(data)});
}
</script>