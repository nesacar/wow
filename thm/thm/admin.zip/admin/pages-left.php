<div id='left'>
  <ul id='navlevo'>
    <li><a href='<?= AURI ?>categories'>Kategorije</a></li>
    <li><a href='<?= AURI ?>pages'>Lista članaka</a></li>
    <li><a href='<?= AURI ?>page_new'>Novi članak</a></li>
    <li><a href='<?= AURI ?>tagcloud'>Lista tagova</a></li>
  </ul>
</div>