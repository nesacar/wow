<h1>Komentari na čekanju</h1>

<div style='height: 400px; float:left; position:relative;'>
<table class='tblh' width=770 border="0" cellpadding="0" cellspacing="0">
<tr class='listtitle' ><th width=64>DATUM</th><th>ČLANAK</th><th>AUTOR</th><th>NASLOV</th><th>KOMENTAR</th><th>PREGLED</th></tr>
<?php
$i = 0;
foreach($comments as $c) {
  $trc = ++$i % 2 ? "nepar":"par";
  @print "<tr class='{$trc}'><td valign=top>".nl2br(date("d.m.Y\nH:i",strtotime($c['posted'])))."</td>"
      ."<td valign=top><a href='".AURI."page_edit/{$c['pid']}'>{$c['ptitle']}</a></td>"
      ."<td valign=top>{$c['author']}</td><td valign=top>{$c['subject']}</td>"
      ."<td valign=top>".nl2br($c['body'])."</td>"
      ."<td><a href='".AURI."comments_review/{$c['pid']}'>pregled</a></td></tr>\n";
}
?>
</table>

