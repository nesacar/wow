<?php if(empty($dist)) return; ?>
<h1>Pregled distributera: <?= $dist['title'] ?></h1>

<div class='group' style='width:760px;'>
  <b><a href="<?= AURI ?>gdk_dist_edit/<?= $dist['id'] ?>">IZMENI PODATKE</a></b> &nbsp; | &nbsp;
  <b><a href="<?= AURI ?>microsite/<?= $dist['id'] ?>">UREDI MICRO SITE</a></b> &nbsp;
</div>
<div class='group' style='width:760px;'>
  <b><a href="<?= AURI ?>gdk_get_csv/<?= $dist['id'] ?>">PREUZMI CSV PROIZVODA</a></b> &nbsp; | &nbsp;
  <form method=post enctype='multipart/form-data' action="<?= AURI ?>gdk_set_csv" style="display: inline-block">
    <input type="hidden" name="did" value="<?= $dist['id'] ?>" />
    <input type="file" name="csv" required='required'/>
    <input type="submit" value="Otpremi CSV proizvoda" style='margin: 0' />
  </form>
</div>

<div class='group' style='width:760px;'>

  <?php if(!empty($dist['logo'])) echo "<img src=\"".SURI.$dist['logo']."\"  style='float: left; width:56px; margin-right: 10px' /> &nbsp; "; ?>
  <table style='width: 320px; float: left; margin-right: 50px'>

    <tr><td>Naziv: </td><td><?= @$dist['title'] ?></td></tr>
    <tr><td>Status:</td><td><?= @$dist['active'] ? "aktivan ".(empty($dist['usr']) || empty($dist['pwd']) ? "(nema pristup)":"(ima pristup)"):"neaktivan" ?> </td></tr>
    <tr><td>E-mail: </td><td><?= @$dist['email'] ?></td></tr>
    <tr><td>Sajt: </td><td><?= @$dist['url'] ?></td></tr>
    <tr><td>Username: </td><td><?= @$dist['usr'] ?></td></tr>
    <tr><td>Broj proizvoda (limit): </td><td><?= Gdk::distProductCT($dist['id']) ." (". @$dist['plimit'] .")" ?></td></tr>
    <tr><td>Značaj (za sortiranje): </td><td><?= @$dist['weight'] ?></td></tr>
  </table>


  <table style='width: 320px; float: left;'>
    <tr><td colspan=2><b>SEO:</b> </td></tr>
    <tr><td valign='top'>Opis: </td><td><?= @$dist['descr'] ?></td></tr>
    <tr><td nowrap valign='top'>Ključne reči: </td><td><?= @$dist['kwrds'] ?></td></tr>
    <tr><td nowrap valign='top'>Adresa (url): </td><td><?= @$dist['furl'] ?></td></tr>
  </table>

  <div class='clear'></div>
  <hr />
  <?= @$dist['html'] ?>
  <hr />
  <div class='clear'></div>

  <b>Brendovi:</b>
  <div class='spacer10'></div>
  <?php foreach($brandList as $b) if(in_array($b['id'],$dist['brands'])) { ?>
    <div style="width: 59px; float: left; margin-right: 20px;">
      <img src="<?= SURI . $b['logo'] ?>" alt="<?= $b['title'] ?>" style="width: 59px; height: 59px;">
    </div>
  <?php } ?>
</div>

<div class='spacer10'></div>
<h2>Lokacije:</h2>
<div class='group'>
  <b><a href='<?= AURI ?>gdk_dist_loc_new/<?= $dist['id'] ?>'>» Dodaj novu lokaciju</a></b>
</div>

<?php foreach($dist['locations'] as $loc){ ?>
  <div class='group'>
    <div class='top'>
      <a href='<?= AURI ?>gdk_dist_loc_edit/<?= $loc['id'] ?>'>
        <?= $loc['pos'] .".". (empty($loc['title']) ? "" : $loc['title'].": ") . $loc['addr'] .", ". $loc['town'] ?>
      </a>
      <div class='del'>
        <label title='Obriši'>
          <input type=button value='X' onClick="obrisiLokaciju('<?= $loc['id'] ?>')"/>
        </label>
      </div>
    </div>
    <div class='spacer0'></div>
  </div>
<?php } ?>

<script type="text/javascript">
function obrisiLokaciju(id) {
  if(!confirm('Brisanje lokacije?')) return false;
  $.post("<?= AURI ?>gdk_dist_loc_del", {lid:id}, function(data){window.location.reload()});
}
</script>