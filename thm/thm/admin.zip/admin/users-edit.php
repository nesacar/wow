<h1>Izmena korisnika</h1>
<div class='group' style='width:420px;'>
<?php if($user['status']=='owner') { ?>
  Vlasnik: <?= $user['name'] ?> <br />
<?php } else { ?>


  <form method=post action="<?= AURI ?>user_save">
    <input type=hidden name='uid' value='<?= $user['id'] ?>' />
    <table>
      <tr><td>Korisnik: </td><td><input type=text name='name' value='<?= $user['name'] ?>'/></td></tr>
      <tr><td>Korisničko ime: </td><td><input type=text name='usr' value='<?= $user['usr'] ?>' required='required' /></td></tr>
      <tr><td>Lozinka: </td><td><input type=password name='pwd' /></td></tr>
      <tr><td>E-mail: </td><td><input type=text name='email'value='<?= $user['email'] ?>' /></td></tr>
      <tr><td>Pristup: </td><td><select name='status'><option value='writer'>Novinar</option><option value='admin' <?= $user['status']=='admin' ? "selected='selected'":""?>>Urednik</option></select>

      <tr><td colspan=2><input type=submit value='SNIMI'/></td></tr>
    </table>
  </form>

<?php } ?>
</div>