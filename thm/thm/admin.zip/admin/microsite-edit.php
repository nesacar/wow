<?php if(empty($dist)) return; ?>
<script type="text/javascript" src="<?= ATURI ?>js/tiny_mce/tiny_mce.js"></script >
<script type="text/javascript" src="<?= ATURI ?>js/tinymce-init.js"></script >


<h1>Micro Site distributera: <?= $dist['title'] ?></h1>
<h2><?= empty($page) ? "Nova stranica" : "Izmena stranice: ".$page['title'] ?></h1>

<div class='group' style='width:760px;'>
  <b><a href="<?= AURI ?>gdk_dist_view/<?= $dist['id'] ?>">NAZAD NA DISTRIBUTERA</a></b> &nbsp; | &nbsp;
  <b><a href="<?= AURI ?>microsite/<?= $dist['id'] ?>">NAZAD NA MICROSITE</a></b>
</div>

<div class='group' style='width:760px;'>
  <form method=post enctype='multipart/form-data' action="<?= AURI ?>microsite_save">
    <input type=hidden name='ms[id]' value='<?= @$page['id'] ?>' />
    <input type=hidden name='ms[did]' value='<?= @$dist['id'] ?>' />
    <input type=hidden name='ms[old_furl]' value='<?= @$page['furl'] ?>' />

    <table>
      <tr><td>Pozicija u meniju:</td><td><input type=text name='ms[pos]' value='<?= @$page['pos'] ?>' required='required' /></td></tr>
      <tr>
        <td>Šablon: </td>
        <td>
          <select name='ms[tpl]' id="sel_ms_tpl" onChange="toggleTpl(this.value)">
            <option value='generic'>Osnovna stranica</option>
            <option value='assortment'>Asortiman</option>
            <option value='galP'>Galerija - uspravne fotografije</option>
            <option value='galL'>Galerija - položene fotografije</option>
            <option value='contact'>Kontakt</option>
          </select>
        </td>
      </tr>
      <tr><td>Prikaz zaglavlja:</td><td><label title='Prikaži zaglavlje u vrhu strane'><input type='checkbox' name='ms[header]' value='1' <?= @$page['header'] ? "checked='checked'":"" ?> /> prikaži zaglavlje u vrhu strane</label></td></tr>
      <tr><td>Naziv:</td><td><input type=text name='ms[title]' value='<?= @$page['title'] ?>' required='required' /></td></tr>
      <tr><td>Adresa (url): </td><td><input type=text name='ms[furl]' value='<?= @$page['furl'] ?>'/></td></tr>

      <tr id="toggler_ms_html"><td colspan=2><textarea name='ms[html]' class='contentEditor' style='width:100%; height:200px'><?= @$page['html'] ?></textarea></td></tr>

      <tr id="toggler_ms_assortment">
        <td>Kategorija asortimana:</td>
        <td>
          <select name='ms[acat]'>
            <option value='0'>Sve kategorije</option>
            <?php
              foreach($catList as $c) {
                echo "<option value='{$c['id']}' ".($c['id']==@$page['acat'] ? "selected='selected'":"").">{$c['pos']}. ".(empty($c['title']) ? "bez naslova":$c['title'])."</option>\n";
                if(!empty($c['sub'])) foreach ($c['sub'] as $s)
                echo "<option value='{$s['id']}' ".($s['id']==@$page['acat'] ? "selected='selected'":"").">-- {$c['pos']}.{$s['pos']}. ".(empty($s['title']) ? "bez naslova":$s['title'])."</option>\n";
              }
            ?>
          </select>
        </td>
      </tr>

      <tr id="toggler_ms_gallery">
        <td>Galerija:</td>
        <td>
          <input type='file' name='photo[]' multiple='multiple' />
          <div class='spacer10'></div>
          <?php if(!empty($gallery)) foreach($gallery as $img) { ?>
            <div style='float: left; border: 1px solid #AAA; background: #FFF; height: 120px; padding: 5px; margin: 0 10px 10px 0; position: relative;'>
              <img style='height: 120px; width: auto' src='<?= $img ?>' />
              <label style='display: block; position: absolute; top: 10px; left: 10px; background-color: #FFF; padding-right: 3px; ' title='označi za brisanje'><input type='checkbox' name='delPhoto[]' value="<?= basename($img) ?>" /> brisanje</label>
            </div>
          <?php } ?>

        </td>
      </tr>

      <tr><td colspan=2><input type=submit value='Potvrdi'/></td></tr>
    </table>

  </form>
</div>

<script type="text/javascript">
function toggleTpl(tpl) {
  $("#toggler_ms_html").hide();
  $("#toggler_ms_assortment").hide();
  $("#toggler_ms_gallery").hide();
  switch(tpl) {
    case 'generic': $("#toggler_ms_html").show(); break;
    case 'assortment': $("#toggler_ms_assortment").show(); break;
    case 'galP': case 'galL': $("#toggler_ms_gallery").show(); break;
    default: break;
  }
}
$(document).ready(function(){
  $("select[name='ms[tpl]']").val('<?= @$page['tpl'] ?>');
  toggleTpl($("select[name='ms[tpl]']").val());
})
</script>