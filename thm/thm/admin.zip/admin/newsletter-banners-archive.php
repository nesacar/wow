<script type="text/javascript">
function checkNLBForm(f){
  if(!f.elements['slika'].value.match(/.+\.(jpe?g|gif|png)$/)){alert('Neispravna ekstenzija slike.'); return false;}
  if(f.elements['url'].value==''){alert('Nije uneta adresa'); return false;}
}
</script>

<h2>Newsletter banners</h2>
[<a href="<?= AURI ?>newsletter/banners">aktivni baneri</a>] | <b>arhiva</b>
<hr />


<div class='group' style='width: 760px'>
<h3>Arhivirani banner-i:</h3>
<?php
  foreach($banners as $b){
    echo "<div style='padding:5px'>Adresa: <a target='_blank' href='http://{$b['url']}'>{$b['url']}</a></div> "
        ."<img src='data:{$b['slikaMime']};base64,{$b['slikaEnc64']}'/><br />"
        ."<a href='".AURI."newsletter/bannerstat/{$b['id']}' class='galleryprivju' style='float: left;'>Statistika</a>"
        ."<a href='".AURI."nl_retarget/{$b['id']}' class='galleryprivju' style='float: right;'>Retarget</a>";
    echo "<div class='clear'></div><hr />\n";
  }
?>

</div>