<h1>Pregled/izmena galerije</h1>
<div id='gallery_edit_div'>
	<?php include "gallery-edit.php"; ?>
</div>

<script type="text/javascript">
function set_gal_img_croppos(ii,iurl,pos){
  $('#'+ii).attr('src','<?= SURI ?>image.php?image='+iurl+'&width=150&cropratio=3:2&cropposition='+pos);
}
function gallery_img_crop(){
  var param = $('#gallery_edit_form').serialize();
  $('#gallery_edit_div').html('<img src="<?= ATURI ?>images/facebox/loading.gif" />');
  $.post("<?= AURI ?>gallery_img_crop/"+Math.random(0,9999),param,function(data){$('#gallery_edit_div').html(data)});
}
</script>