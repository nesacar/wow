<div id='left'>
	<ul id='navlevo'>
		<li><a href='<?= AURI ?>user_new'>Novi korisnik</a></li>
		<li><a href='<?= AURI ?>users'>Lista korisnika</a></li>
    <!-- li><a href='<?= AURI ?>arhiclub'>Arhi Club</a></li -->
	</ul>
</div>