  <h2>Newsletter</h2>
  <hr />
  <div class='group'>
  <h3>Greška</h3>
  <?php echo $err->getMessage(); ?>
  <br />
  <a href='javascript:history.go(-1)'>Nazad</a>
  </div>
  