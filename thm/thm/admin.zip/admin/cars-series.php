<h1>Lista serija</h1>
<div class='group' style='width:757px;'>
  Brend:
  <select id='brand_select' onChange="setFilter(this.value)">
    <option value='-1'>Odaberite brend</option>
    <option value='0'>Serije bez brenda</option>
    <?php foreach($brandList as $b) echo "<option value='{$b['id']}'>{$b['title']}</option>\n"; ?>
  </select>

</div>

<div id='series_list'>
  <?php include "cars-series-list.php"; ?>
</div>

<script type="text/javascript">
function setFilter(brand){
  $.post("<?= AURI ?>/car_series_list",{brand:brand},function(data){$("#series_list").html(data)});
}
function obrisiSeriju(id) {
  if(!confirm('Brisanje serije?\nUkoliko obrišete seriju svi modeli će postati nevidljivi i neće se prikazivati na sajtu!\n\nAdministrator mora da interveniše za povraćaj kategorizacije.\nADMIN: Nikola Ivković, 063 230 191 ili nikola.ivkovic@weboperater.rs')) return false;
  $.post("<?= AURI ?>car_series_del", {sid:id}, function(data){setFilter($('#brand_select').val())});
}
</script>