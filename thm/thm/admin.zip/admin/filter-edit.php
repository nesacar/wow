<h1>Izmena filtera</h1>
<h2><?= empty($filter['img']) ? "" : "<img src='".SURI.$filter['img']."' width='24' height='24' /> &nbsp; "?><?= $filter['title'] ?></h2>
<div class='group' style='width: 760px'>
  <form method="post" enctype='multipart/form-data' action="<?= AURI ?>filter_update">
    <input type='hidden' name='id' value='<?= $filter['id'] ?>' />
    Naziv: <input type='text' name='ftitle' value='<?= $filter['title'] ?>' required='required' /> &nbsp; sličica (24x24): <input type='file' name='img' /> <input type='submit' value='Potvrdi' />
  </form>
</div>


