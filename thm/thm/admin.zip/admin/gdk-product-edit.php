<h1><?= empty($product) ? "GDK NOVI PROIZVOD" : "GDK Izmena proizvoda: ".$product['title'] ?></h1>
<div class='group' style='width:760px;'>
  <form method=post enctype='multipart/form-data' action="<?= AURI ?>gdk_product_save">
    <input type=hidden name='product[id]' value='<?= @$product['id'] ?>' />
    <input type=hidden name='product[old_furl]' value='<?= @$product['furl'] ?>' />

    <table width="100%">
      <tr><td>Brend: </td><td>
        <select name='product[brand]' required='required'>
          <option value=''>Odaberite brend</option>
          <?php foreach($brandList as $b) echo "<option value='{$b['id']}' ".($b['id']==@$product['brand'] ? "selected='selected'":"").">{$b['title']}</option>\n"; ?>
        </select>
      </td></tr>
      <tr><td>Distributer: </td><td>
        <select name='product[dist]' required='required'>
          <option value=''>Odaberite distributera</option>
          <?php foreach($distList as $d) echo "<option value='{$d['id']}' ".($d['id']==@$product['dist'] ? "selected='selected'":"").">{$d['title']}</option>\n"; ?>
        </select>
      </td></tr>
      <tr><td>Kategorija: </td><td>
        <select name='product[cat]'>
          <option value='0'>Odaberite kategoriju</option>
          <?php
            foreach($catList as $c) {
              echo "<option value='{$c['id']}' ".($c['id']==@$product['cat'] ? "selected='selected'":"").">{$c['pos']}. ".(empty($c['title']) ? "bez naslova":$c['title'])."</option>\n";
              if(!empty($c['sub'])) foreach ($c['sub'] as $s)
                echo "<option value='{$s['id']}' ".($s['id']==@$product['cat'] ? "selected='selected'":"").">→ {$c['pos']}.{$s['pos']}. ".(empty($s['title']) ? "bez naslova":$s['title'])."</option>\n";
            }
          ?>
        </select>
      </td></tr>

      <tr><td>Naziv: </td><td><input type=text name='product[title]' value='<?= @$product['title'] ?>' required='required' /></td></tr>
      <tr><td>Cena: </td><td><label title="Ukoliko je cena 0, proizvod neće biti prikazivan"><input type=text name='product[cena]' value='<?= @$product['cena'] ?>' /></label> <span class='tip'>Ukoliko je cena 0, proizvod neće biti prikazivan</span></td></tr>
      <tr>
        <td>Tip cene: </td>
        <td>
          <select name='product[cena_tip]'>
            <option value='fix'>fiksna</option>
            <option value='upit'>na upit</option>
            <option value='min'>cena OD</option>
            <option value='max'>cena DO</option>
          </select>
          <span class='tip'>Ukoliko je cena na upit, u polje "cena" upišite 1 da bi proizvod bio vidljiv</span>
          <script type="text/javascript">$("select[name='product[cena_tip]']").val('<?= @$product['cena_tip'] ?>')</script>
        </td>
      </tr>
      <tr>
        <td>Valuta: </td>
        <td>
          <select name='product[valuta]'>
            <option value='rsd'>RSD</option>
            <option value='eur'>EUR</option>
          </select>
          <script type="text/javascript">$("select[name='product[valuta]']").val('<?= @$product['valuta'] ?>')</script>
        </td>
      </tr>
      <tr><td>Widget naziv: </td><td><input type=text name='product[wtitle]' value='<?= @$product['wtitle'] ?>' /> <span class='tip'>ukoliko je polje prazno, proizvod se ne pojavljuje u widgetu</span></td></tr>


      <tr><td colspan=2><hr /><b>SEO:</b> </td></tr>
      <tr><td valign='top'>Opis: </td><td><textarea name='product[descr]'><?= @$product['descr'] ?></textarea></td></tr>
      <tr><td>Ključne reči: </td><td><input type=text name='product[kwrds]'  value='<?= @$product['kwrds'] ?>'/> <span class='tip'>Nekoliko ključnih reči, odvojenih zapetom.</span></td></tr>
      <tr><td>Adresa (url): </td><td><input type=text name='product[furl]' value='<?= @$product['furl'] ?>'/> <span class='tip'>Izbegavajte navodnike, zagrade i druge specijalne karaktere.</span></td></tr>
      <tr><td colspan=2><hr /></td></tr>
    </table>

    <table width="100%">
      <tr><th>Info 1</th><th>Info 2</th><th>Info 3</th></tr>
      <tr>
        <td align='center'><input type=text name='product[info1h]' value='<?= @$product['info1h'] ?>' /></td>
        <td align='center'><input type=text name='product[info2h]' value='<?= @$product['info2h'] ?>' /></td>
        <td align='center'><input type=text name='product[info3h]' value='<?= @$product['info3h'] ?>' /></td>
      </tr>
      <tr>
        <td align='center'><textarea name='product[info1]'><?= @$product['info1'] ?></textarea></td>
        <td align='center'><textarea name='product[info2]'><?= @$product['info2'] ?></textarea></td>
        <td align='center'><textarea name='product[info3]'><?= @$product['info3'] ?></textarea></td>
      </tr>
    </table>


    <hr/>
    <p><b>Fotografije:</b></p>
    <div class='tip'>U galeriju možete otpremiti najviše <?= GDK_GALLERY_LIMIT ?> fotografija.</div>
    <div class='spacer10'></div>
    <?php
      if(empty($product['gallery'])) {
        $db = db::getInstance();
        $distNames = Gdk::distNames();
        $oldDistId = $db->selectValue("SELECT id FROM gdk_distributor WHERE naziv=?",array($distNames[$product['dist']]));
        echo "POGLEDATI U proizvodi / {$oldDistId} / {$product['furl']} /\n<div class='spacer10'></div>";
      }
    ?>
    <input type='file' name='photo[]' multiple='multiple' />
    <div class='spacer10'></div>

    <?php if(!empty($product['gallery'])) foreach($product['gallery'] as $img) { ?>
      <div style='float: left; border: 1px solid #AAA; background: #FFF; height: 120px; padding: 5px; margin: 0 10px 10px 0; position: relative;'>
        <img style='height: 120px; width: auto' src='<?= $img ?>' />
        <label style='display: block; position: absolute; top: 10px; left: 10px; background-color: #FFF; padding-right: 3px; ' title='označi za brisanje'><input type='checkbox' name='delPhoto[]' value="<?= basename($img) ?>" /> brisanje</label>
      </div>
    <?php } ?>

    <div class='spacer10'></div>

    <hr />

    <input type=submit value='Potvrdi'/>
  </form>
</div>