<div style='height: 400px; float:left; position:relative;'>
<table class='tblh' width=770 border="0" cellpadding="0" cellspacing="0">
<tr class='listtitle' ><th>E-mail</th><th>Ime</th><th>Grad</th><th>Status</th></tr>
<?php
$i = 0;
foreach($aList as $a) {
  $trc = ++$i % 2 ? "nepar":"par";
  if($u['status']=='inactive') $trc = "invisible";

  echo "<tr class='{$trc}'><td><a href='".AURI."architect_edit/{$a['id']}'>{$a['email']}</a></td>"
      ."<td>{$a['title']} {$a['name']} {$a['surname']}</td><td>{$a['town']}</td><td>{$a['status']}</td></tr>\n";
}
?>
</table>
</div>

<?php
if($pCnt > 1){
  echo "<div class='group' style='width:755px;'>\n";
  if($pNum == 1) echo "« PREDHODNA | <b>1</b> | ";
  else {
    echo "<a href=\"javascript:setPage('".($pNum-1)."')\">« prethodna</a> | ";
    echo "<a href=\"javascript:setPage(1)\">1</a> | ";

    if($pNum > 2) echo " ... | <b>{$pNum}</b> | ";
    else echo " <b>2</b> | ";

  }
  if($pCnt > $pNum+1) echo "... | ";
  if($pNum == $pCnt) echo " sledeća »";
  else {
    echo "<a href=\"javascript:setPage('{$pCnt}')\">{$pCnt}</a> | ";
    echo "<a href=\"javascript:setPage('".($pNum+1)."')\">SLEDEĆA »</a>";
  }
?>
<div style='float:right'>STRANA:
<input type=text id='jump_to_page' style='width:16px;text-align:right' onkeydown="if(event.which==13) setPage(0)" />
<a href="javascript:setPage(0)">IDI »</a>
</div>
</td></tr>
<?
} // end if($page_count>1);
?>
