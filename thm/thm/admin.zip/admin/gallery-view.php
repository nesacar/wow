<?php

if(!is_dir($gPath)) {
?>
  u sekciji "FAJLOVI" u folderu <br />
  <b>chest/<?= $pgt['gfolder'] ?></b><br />
  kreirajte podfolder <br />
  <b><?= $page['furl'] ?></b><br />
  i u njega upload-ujte
  željeni broj slika u razmeri 3:2<br /><br />
<?php

} else {
  $w = 600; $h=400;

  $arr = scandir($gPath);


  echo "<div style='height: 420px; overflow: auto;'>";

  $i_found = 0;
  foreach($arr as $a) {
    $info = @getimagesize($gPath."/".$a);
    if(empty($info)) continue;
    $i_found++;

    lg_print($gURI,$a);

  }


  if($i_found==0){
    echo "<p>u sekciji \"FAJLOVI\" u folder<br /><b>chest/{$pgt['gfolder']}/{$page['furl']}</b><br />upload-ujte željeni broj slika u razmeri 3:2</p>";
  }

  echo "</div>";


}
?>




<?php
function lg_print($uriPref,$img){
  echo "<div style='clear:both;'>
          <img style='width: 300px; margin-bottom: 10px' src='{$uriPref}/{$img}' />
        </div>
  ";
}
?>
