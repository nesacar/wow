<?php
if(!empty($_POST['luxold_do'])) $_SESSION['luxold'] = @$_POST['luxold'];

?>

<h1><?= $setup->main_title ?> - Administracija</h1>



<form method="post" action="<?= AURI ?>">
  <input type='hidden' name='luxold_do' value='1' />
  <label title="Pregled novih šablona">
    <input type="checkbox" name="luxold" <?= empty($_SESSION['luxold']) ? "" : "checked='checked'" ?> /> Pregled starih šablona
  </label>
  <input type='submit' value='Potvrdi' />
</form>

<?php
/*
$path = __SITE_PATH ."/gdktmp/";
$arr = scandir($path);

$dst = _CHEST . "proizvodi/movem-fashion/";


foreach($arr as $fn) {
  if(!is_file($path.$fn)) continue;
  $dir = substr($fn,0,4);

  copy($path.$fn,$dst.$dir."/".$fn);

}

*/

exit;
?>

<form method="post"  enctype='multipart/form-data' >
  <input type="file" name="zipfajl" /> <input type="submit" value="Daj ZIP" />
</form>
<br /><br />
<plaintext>
<?php

if(!empty($_FILES['zipfajl']) && !$_FILES['zipfajl']['error']) {
  $fajl = $_FILES['zipfajl'];
  echo "imam fajl {$fajl['name']}...\n";


  $zip = new ZipArchive;
  if ($zip->open($_FILES['zipfajl']['tmp_name']) === true) {
    for($i = 0; $i < $zip->numFiles; $i++) {

      echo $zip->getNameIndex($i)."\n";


    }

  }

  else echo "Fajl nije ZIP!\n";


}

exit;

echo THIS_HOUR;

/*
echo "<plaintext>";
$db = db::getInstance();

$models = $db->select("SELECT * FROM ".DB_PREF."model");

$search = array("klasse","class");
$replace = array("Klasa","Klasa");

$q = "UPDATE ".DB_PREF."model SET title=? WHERE id=?";

foreach($models as $m){
  $nt = str_ireplace($search,$replace,$m['title']);

  if($nt!=$m['title']) echo $m['title'] .' -> '.$nt."\n";
  else echo "*** OK *** {$m['title']}\n";

}


888888888888888888888888888888888888888888888888888888888

$pages = $db->select("SELECT * FROM ".DB_PREF."page WHERE cat!=46");

foreach($pages as $p){
  $pgt = $db->selectRow("SELECT * FROM ".DB_PREF."pgtype WHERE id=?",array($p['pgt']));

  if(empty($p['furl'])) {
    echo "PANIKA!!! prazan furl {$p['id']} {$p['title']} \n\n *** \n\n";
    continue;
  }

  $src = __SITE_PATH."/chest/littlegallery/{$p['furl']}";

  $dst = __SITE_PATH."/chest/{$pgt['gfolder']}/{$p['furl']}";

  if(is_dir($src) && !empty($pgt['gfolder'])) `mv $src $dst`;

  else echo "*** NISAM NASAO: $src \n\n";

}


exit;

gdk-brand.php
gdk-brand-append.php
gdk-brand-products.php
gdk-cat.php
gdk-cat-append.php
gdk-dist-append.php
gdk-dist-products.php
gdk-product.php
gdkwidget.php
page-gdk.php
microsite-assortment.php

*/
?>
