<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.8.18/jquery-ui.min.js" type="text/javascript"></script>
<link rel="stylesheet" href="<?= ATURI ?>css/humanity/jquery-ui-1.8.18.custom.css">
<script type="text/javascript">
$(document).ready(function() {
  $(".datum").datepicker({dateFormat:'yy-mm-dd',firstDay:1,changeMonth:true,changeYear:true,onSelect:setFilter,
    dayNamesMin:['N','P','U','S','Č','P','S'],
    monthNamesShort:['Jan','Feb','Mar','Apr','Maj','Jun','Jul','Avg','Sep','Okt','Nov','Dec']
    });
});
</script>

<h1>GDK LISTA PROIZVODA</h1>

<div class='group'>
  <b><a href='<?= AURI ?>gdk_product_edit'>» Dodaj novi proizvod</a></b>
</div>

<div class='group' style='width:757px;'>
  <form onSubmit="return false" id="gpf_form">
    <input type=text name='search' id='gpf_search' onKeyUp="setFilter()" value='<?= @$_SESSION['gpf_search'] ?>' placeholder='Pretraga' style='width: 240px'/>
    <label title='Proizvodi u widget-u'><input type="checkbox" name='widget' id='gpf_widget' onChange="setFilter()" value='1' <?= empty($_SESSION['gpf_widget']) ? "":"checked='checked'" ?> /> widget </label>
    <br />

    Brand:
    <select name='brand' id='gpf_brand' onChange="setFilter()" style='width: 90px'>
      <option value='0'>Svi brendovi</option>
      <?php
        foreach($brandList as $b) {
          echo "<option value='{$b['id']}' ".($b['id']==@$_SESSION['gpf_brand'] ? "selected='selected'":"").">".(empty($b['title']) ? "bez naziva":$b['title'])."</option>\n";
        }
      ?>
    </select>

    Distributer:
    <select name='dist' id='gpf_dist' onChange="setFilter()" style='width: 90px'>
      <option value='0'>Svi distributeri</option>
      <?php
        foreach($distList as $d) {
          echo "<option value='{$d['id']}' ".($d['id']==@$_SESSION['gpf_dist'] ? "selected='selected'":"").">".(empty($d['title']) ? "bez naziva":$d['title'])."</option>\n";
        }
      ?>
    </select>

    Kategorija:
    <select name='cat' id='gpf_cat' onChange="setFilter()" style='width: 90px'>
      <option value='0'>Sve kategorije</option>
      <?php
        foreach($catList as $c) {
          echo "<option value='{$c['id']}' ".($c['id']==@$_SESSION['gpf_cat'] ? "selected='selected'":"").">{$c['pos']}. ".(empty($c['title']) ? "bez naslova":$c['title'])."</option>\n";
          if(!empty($c['sub'])) foreach ($c['sub'] as $s)
          echo "<option value='{$s['id']}' ".($s['id']==@$_SESSION['gpf_cat'] ? "selected='selected'":"").">-- {$c['pos']}.{$s['pos']}. ".(empty($s['title']) ? "bez naslova":$s['title'])."</option>\n";
        }
      ?>
    </select>


    od <input type=text name='d1' id='gpf_d1' value='<?= @$_SESSION['gpf_d1'] ?>' class='datum' style='width: 66px'/>
    do <input type=text name='d2' id='gpf_d2' value='<?= @$_SESSION['gpf_d2'] ?>' class='datum' style='width: 66px'/>
    <input type=button value='X' onClick="resetFilter()" />
    <span style='float:right'>
      <select name='listlimit' onChange="setFilter()" title="članaka po strani">
      	<option <?= @$_SESSION['gpf_listlimit']==50  ? "selected='selected'":"" ?>>50</option>
      	<option <?= @$_SESSION['gpf_listlimit']==100 ? "selected='selected'":"" ?>>100</option>
      	<option <?= @$_SESSION['gpf_listlimit']==200 ? "selected='selected'":"" ?>>200</option>
      	<option <?= @$_SESSION['gpf_listlimit']==500 ? "selected='selected'":"" ?>>500</option>
      </select>
    </span>
  </form>

</div>

<div id='product_filtered_list' style='clear:both'>
<?php include "gdk-product-list.php"; ?>
</div>

<script type="text/javascript">
function setFilter(){
  $.post("<?= AURI ?>gdk_product_list",$("#gpf_form").serialize(),function(data){$("#product_filtered_list").html(data)});
}
function resetFilter(){
  $("#gpf_search").val('');
  $("#gpf_widget").attr('checked',false);
  $("#gpf_cat").val(''); $("#gpf_dist").val(''); $("#gpf_brand").val('');
  $("#gpf_d1").val('');$("#gpf_d2").val('');
  setFilter();
}
function setPage(p){
  if(p==0) p = $('#jump_to_page').val();
  $.post("<?= AURI ?>gdk_product_list",{page_num:p},function(data){$("#product_filtered_list").html(data)});
}
</script>