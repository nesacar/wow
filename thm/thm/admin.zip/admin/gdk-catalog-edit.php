<h1><?= empty($catalog) ? "Novi katalog distributera" : "Izmena kataloga: " . $catalog['title'] ?>"</h1>
<div class='group' style='width:420px;'>
  <form method=post enctype='multipart/form-data' action="<?= AURI ?>gdk_catalog_save">
    <input type=hidden name='catalog[id]' value='<?= @$catalog['id'] ?>' />
    <table>
      <tr><td>Distributer:</td>
        <td>
          <select name='catalog[did]' required='required'>
            <option value=''>Odaberite distributera</option>
            <?php foreach($distList as $d) echo "<option value='{$d['id']}' ".(@$catalog['did']==$d['id'] ? "selected='selected'":"").">".(empty($d['title']) ? "bez naziva":$d['title'])."</option>\n" ?>
          </select>
        </td>
      </tr>
      <tr><td>Naziv:</td><td><input type=text name='catalog[title]' value='<?= @$catalog['title'] ?>' required='required' /></td></tr>

      <tr><td>PDF: </td><td><input type=file name='pdf' /></td></tr>
      <tr><td colspan=2><hr /></td></tr>
      <tr><td colspan=2>
        <?php if(!empty($catalog['path']) && is_file(__SITE_PATH."/".$catalog['path'])) { ?>
          [<a href="<?= GDKURI ?>katalog/<?= $dist['furl'] ?>/<?= $catalog['id'] ?>"><b>Preuzmi PDF</b></a>]
        <?php } ?>
      </td></tr>


      <tr><td colspan=2><input type=submit value='Potvrdi'/></td></tr>
    </table>
  </form>
</div>